import 'package:flutter/material.dart';
import 'package:myacs/main.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';

class GlobalMemberProfilePage extends StatefulWidget {
  final String userId; // Pass the UUID of the user

  const GlobalMemberProfilePage({super.key, required this.userId});

  @override
  State<GlobalMemberProfilePage> createState() => _GlobalMemberProfilePageState();
}

class _GlobalMemberProfilePageState extends State<GlobalMemberProfilePage> {
  late Future<Map<String, dynamic>> _profileFuture;

  @override
  void initState() {
    super.initState();
    _profileFuture = _fetchProfile();
  }

  Future<Map<String, dynamic>> _fetchProfile() async {
    final response = await supabase
        .from('profiles')
        .select()
        .eq('ID', widget.userId)
        .single();
    return response;
  }

  // Helper to launch URLs for email and phone
  Future<void> _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      // Show an error if the URL can't be launched
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not launch $url'), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Employee Details'),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _profileFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Profile not found.'));
          }

          final profile = snapshot.data!;
          // --- MODIFIED: Use PHOTO_URL instead of AVATAR_URL.
          final photoUrl = profile['PHOTO_URL'];
          final name = profile['EMPNAME'] ?? 'N/A';
          final empNo = profile['EMPNO'] ?? 'N/A';
          final email = profile['EMAIL'];
          final phone = profile['PHONE'];
          final dob = profile['DOB'] != null ? DateFormat.yMMMMd().format(DateTime.parse(profile['DOB'])) : 'N/A';
          final empClass = profile['EMP_CLASS']?.toString() ?? 'N/A';

          return ListView(
            padding: const EdgeInsets.all(16.0),
            children: [
              Center(
                child: CircleAvatar(
                  radius: 60,
                  // --- MODIFIED: Use photoUrl for the background image.
                  backgroundImage: (photoUrl != null && photoUrl.isNotEmpty) ? NetworkImage(photoUrl) : null,
                  child: (photoUrl == null || photoUrl.isEmpty) ? const Icon(Icons.person, size: 60) : null,
                ),
              ),
              const SizedBox(height: 16),
              Text(name, style: Theme.of(context).textTheme.headlineSmall, textAlign: TextAlign.center),
              const SizedBox(height: 24),
              _buildDetailCard(context, [
                _buildDetailRow(context, 'Employee No.', empNo),
                _buildDetailRow(context, 'Class', empClass),
                _buildDetailRow(context, 'Date of Birth', dob),
              ]),
              const SizedBox(height: 16),
              _buildDetailCard(context, [
                _buildContactRow(context, 'Email', email, Icons.email_outlined, () {
                  if (email != null) _launchURL('mailto:$email');
                }),
                _buildContactRow(context, 'Phone', phone, Icons.phone_outlined, () {
                  if (phone != null) _launchURL('tel:$phone');
                }),
              ]),
            ],
          );
        },
      ),
    );
  }

  Widget _buildDetailCard(BuildContext context, List<Widget> children) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(children: children),
      ),
    );
  }

  Widget _buildDetailRow(BuildContext context, String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[600])),
          Text(value, style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildContactRow(BuildContext context, String title, String? value, IconData icon, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[600])),
          Row(
            children: [
              Text(value ?? 'N/A', style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold)),
              if (value != null) ...[
                const SizedBox(width: 8),
                IconButton(
                  icon: Icon(icon, color: Theme.of(context).primaryColor, size: 20),
                  onPressed: onTap,
                  visualDensity: VisualDensity.compact,
                ),
              ]
            ],
          ),
        ],
      ),
    );
  }
}
