import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:myacs/main.dart';
import 'package:myacs/pages/history_page.dart';
import 'package:myacs/pages/home_page.dart';
import 'package:myacs/pages/profile_page.dart';
import 'package:myacs/widgets/nav_bar.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;
  int _previousIndex = 0;
  DateTime? _lastPressedAt;

  // --- NEW: State to hold profile data and loading status ---
  Map<String, dynamic>? _profile;
  bool _isLoading = true;

  static final List<Widget> _pages = <Widget>[
    const HomePage(),
    const HistoryPage(),
    const Center(), // Placeholder for the "Regularize" action
    const ProfilePage(),
  ];

  @override
  void initState() {
    super.initState();
    // --- NEW: Fetch profile when the page loads ---
    _fetchProfile();
  }

  // --- NEW: Function to fetch user profile from Supabase ---
  Future<void> _fetchProfile() async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
    });
    try {
      final userId = supabase.auth.currentUser!.id;
      final data =
      await supabase.from('profiles').select().eq('ID', userId).single();
      if (mounted) {
        setState(() {
          _profile = data;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        // Optionally, show an error message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error fetching profile: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  void _onItemTapped(int index) {
    // Prevent state update for non-page indices (like the AI button)
    if (index == 0 || index == 1 || index == 3) {
      setState(() {
        _previousIndex = _selectedIndex;
        _selectedIndex = index;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) {
        if (didPop) return;
        final now = DateTime.now();
        if (_lastPressedAt == null ||
            now.difference(_lastPressedAt!) > const Duration(seconds: 2)) {
          _lastPressedAt = now;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('Press back again to exit'),
                duration: Duration(seconds: 2)),
          );
        } else {
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        body: Stack(
          children: [
            // --- UPDATED: Show loading indicator or page content ---
            _isLoading
                ? const Center(child: CircularProgressIndicator())
                : AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              layoutBuilder: (Widget? currentChild, List<Widget> previousChildren) {
                return Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    ...previousChildren,
                    if (currentChild != null) currentChild,
                  ],
                );
              },
              transitionBuilder: (Widget child, Animation<double> animation) {
                final bool isSlidingRight = _selectedIndex > _previousIndex;

                final inAnimation = Tween<Offset>(
                  begin: Offset(isSlidingRight ? 1.0 : -1.0, 0.0),
                  end: Offset.zero,
                ).animate(CurvedAnimation(
                  parent: animation,
                  curve: Curves.easeInOut,
                ));

                final outAnimation = Tween<Offset>(
                  begin: Offset.zero,
                  end: Offset(isSlidingRight ? -0.3 : 0.3, 0.0),
                ).animate(CurvedAnimation(
                  parent: animation,
                  curve: Curves.easeInOut,
                ));

                if (child.key == ValueKey<int>(_selectedIndex)) {
                  return ClipRect(
                    child: SlideTransition(
                      position: inAnimation,
                      child: child,
                    ),
                  );
                } else {
                  return ClipRect(
                    child: SlideTransition(
                      position: outAnimation,
                      child: child,
                    ),
                  );
                }
              },
              child: Container(
                key: ValueKey<int>(_selectedIndex),
                child: _pages[_selectedIndex],
              ),
            ),
            // --- UPDATED: Pass the fetched profile to the nav bar ---
            FloatingNavBar(
              activeIndex: _selectedIndex,
              onTabSelected: _onItemTapped,
              userProfile: _profile,
            ),
          ],
        ),
      ),
    );
  }
}
