import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:myacs/main.dart';
import 'package:myacs/pages/team_member_profile_page.dart';
import 'package:myacs/pages/global_member_profile_page.dart';
import 'package:provider/provider.dart';
import 'package:myacs/providers/attendance_provider.dart';

// Enums to manage the state of the search and filters
enum SearchMode { requests, team, global }
enum DateFilterMode { none, day, week, month, range }
enum ViewMode { detail, tiles }
enum SortOption { date, employeeName, employeeNumber, reason }
enum SortDirection { ascending, descending }


class ApproveRegularizationsPage extends StatefulWidget {
  const ApproveRegularizationsPage({super.key});

  @override
  State<ApproveRegularizationsPage> createState() => _ApproveRegularizationsPageState();
}

class _ApproveRegularizationsPageState extends State<ApproveRegularizationsPage> {
  List<dynamic> _allRequests = []; // Holds all pending requests for local filtering
  List<dynamic> _filteredResults = []; // The list that is actually displayed
  bool _isLoading = true;
  String _errorMessage = '';

  final TextEditingController _searchController = TextEditingController();
  Timer? _debounce;
  SearchMode _searchMode = SearchMode.requests;

  // State for sorting and filtering
  ViewMode _viewMode = ViewMode.detail;
  SortOption _sortOption = SortOption.date;
  SortDirection _sortDirection = SortDirection.descending;
  DateFilterMode _dateFilterMode = DateFilterMode.none;
  DateTime? _startDate;
  DateTime? _endDate;

  // State for pagination
  final ScrollController _scrollController = ScrollController();
  final int _pageSize = 10;
  int _currentPage = 0;
  bool _hasMore = true;
  bool _isFetchingMore = false;


  @override
  void initState() {
    super.initState();
    _fetchInitialRequests();
    _searchController.addListener(_onSearchChanged);
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  void _onScroll() {
    // Check if we are at the end of the list and need to fetch more data
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 200 &&
        !_isFetchingMore && _hasMore && _searchMode == SearchMode.requests) {
      _fetchPaginatedRequests();
    }
  }


  void _onSearchChanged() {
    if (_searchMode == SearchMode.team || _searchMode == SearchMode.global) {
      if (_debounce?.isActive ?? false) _debounce!.cancel();
      _debounce = Timer(const Duration(milliseconds: 500), _fetchData);
    } else {
      _filterLocalData();
    }
    setState(() {});
  }

  void _toggleSearchMode() {
    setState(() {
      if (_searchMode == SearchMode.requests) {
        _searchMode = SearchMode.team;
      } else if (_searchMode == SearchMode.team) {
        _searchMode = SearchMode.global;
      } else {
        _searchMode = SearchMode.requests;
      }

      if (_searchController.text.isNotEmpty) {
        _searchController.clear();
      } else {
        _fetchData();
      }
    });
  }

  Future<void> _fetchData() async {
    switch (_searchMode) {
      case SearchMode.team:
        _fetchProfileSearchResults();
        break;
      case SearchMode.global:
        _fetchGlobalProfileSearchResults();
        break;
      case SearchMode.requests:
      default:
        _fetchInitialRequests();
        break;
    }
  }

  Future<void> _fetchInitialRequests() async {
    setState(() {
      _isLoading = true;
      _currentPage = 0;
      _allRequests = [];
      _filteredResults = [];
      _hasMore = true;
    });
    await _fetchPaginatedRequests();
    setState(() => _isLoading = false);
  }

  Future<void> _fetchPaginatedRequests() async {
    if (_isFetchingMore || !_hasMore) return;

    setState(() => _isFetchingMore = true);
    try {
      final profile = Provider.of<AttendanceProvider>(context, listen: false).profile;
      if (profile == null || profile['EMPNO'] == null) throw 'Your profile could not be loaded.';
      final managerEmpNo = profile['EMPNO'];

      // 1. Get EMPNOs of all team members reporting to the manager.
      final teamProfilesResponse = await supabase
          .from('profiles')
          .select('EMPNO')
          .eq('CONTROLLING', managerEmpNo);

      final List<dynamic> teamEmpNos = teamProfilesResponse.map((p) => p['EMPNO']).toList();

      if (teamEmpNos.isEmpty) {
        if (mounted) setState(() { _hasMore = false; _isLoading = false; _isFetchingMore = false; });
        return;
      }

      // 2. Fetch a page of attendance records for those team members.
      // --- FIXED: Corrected the query to properly fetch all pending requests. ---
      final attendanceResponse = await supabase
          .from('attendance')
          .select('*')
          .inFilter('EMPNO', teamEmpNos)
          .or('APPROVAL_STATUS.is.null,APPROVAL_STATUS.eq.') // Check for NULL or empty string
          .not('REASON', 'is', null) // Ensure a reason exists
          .order('SHIFTDATE', ascending: false)
          .range(_currentPage * _pageSize, (_currentPage + 1) * _pageSize - 1);

      final List<Map<String, dynamic>> attendanceData = List<Map<String, dynamic>>.from(attendanceResponse);

      if (attendanceData.isEmpty) {
        if (mounted) setState(() { _hasMore = false; });
        return;
      }

      // 3. Fetch the profiles for the attendance records we just got.
      final uniqueEmpNosInPage = attendanceData.map((a) => a['EMPNO']).toSet().toList();
      final profilesResponse = await supabase
          .from('profiles')
          .select('*')
          .inFilter('EMPNO', uniqueEmpNosInPage);

      // Create a map for easy lookup of profiles by EMPNO.
      final Map<String, dynamic> profilesMap = {
        for (var p in profilesResponse) p['EMPNO']: p
      };

      // 4. Manually combine the attendance data with the profile data.
      final List<Map<String, dynamic>> newRequests = attendanceData.map((att) {
        return {
          ...att, // All attendance data
          'profiles': profilesMap[att['EMPNO']] // Embed the profile data
        };
      }).toList();


      if (!mounted) return;
      setState(() {
        _allRequests.addAll(newRequests);
        _hasMore = newRequests.length == _pageSize;
        _currentPage++;
        _filterLocalData();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _errorMessage = 'Error fetching requests: $e');
    } finally {
      if (mounted) setState(() => _isFetchingMore = false);
    }
  }


  Future<void> _fetchProfileSearchResults() async {
    if (!mounted) return;
    setState(() => _isLoading = true);
    try {
      final profile = Provider.of<AttendanceProvider>(context, listen: false).profile;
      if (profile == null || profile['EMPNO'] == null) throw 'Your profile could not be loaded.';

      final managerEmpNo = profile['EMPNO'];
      final searchTerm = _searchController.text.trim();

      // Start building the query to find team members.
      var query = supabase
          .from('profiles')
          .select()
          .eq('CONTROLLING', managerEmpNo);

      // If there's a search term, add a filter for name or employee number.
      if (searchTerm.isNotEmpty) {
        query = query.or('EMPNAME.ilike.%$searchTerm%,EMPNO.ilike.%$searchTerm%');
      }

      final response = await query;

      if (!mounted) return;
      setState(() {
        _filteredResults = response;
        _isLoading = false;
        _errorMessage = '';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Error searching team: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _fetchGlobalProfileSearchResults() async {
    final searchTerm = _searchController.text.trim();
    // Only search if there are at least 3 characters.
    if (searchTerm.length < 3) {
      setState(() {
        _filteredResults = [];
        _isLoading = false;
      });
      return;
    }

    if (!mounted) return;
    setState(() => _isLoading = true);
    try {
      // Query the profiles table directly for any matching employee.
      final response = await supabase
          .from('profiles')
          .select()
          .or('EMPNAME.ilike.%$searchTerm%,EMPNO.ilike.%$searchTerm%')
          .limit(20); // Limit results for performance.

      if (!mounted) return;
      setState(() {
        _filteredResults = response;
        _isLoading = false;
        _errorMessage = '';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Error during global search: $e';
        _isLoading = false;
      });
    }
  }

  void _filterLocalData() {
    final query = _searchController.text.toLowerCase();

    setState(() {
      _filteredResults = _allRequests.where((item) {
        final profileData = item['profiles'];
        if (profileData == null) return false;

        final requesterName = (profileData['EMPNAME'] ?? '').toLowerCase();
        final requesterEmpNo = (profileData['EMPNO'] ?? '').toLowerCase();
        final reason = (item['REASON'] ?? '').toLowerCase();
        final matchesSearch = query.isEmpty || requesterName.contains(query) || requesterEmpNo.contains(query) || reason.contains(query);

        bool matchesDate = true;
        if (_startDate != null && _endDate != null) {
          final requestDate = DateTime.parse(item['SHIFTDATE']);
          matchesDate = !requestDate.isBefore(_startDate!) && !requestDate.isAfter(_endDate!);
        }

        return matchesSearch && matchesDate;
      }).toList();
      _sortRequests();
    });
  }

  void _sortRequests() {
    _filteredResults.sort((a, b) {
      int comparison;
      final profileA = a['profiles'];
      final profileB = b['profiles'];

      switch (_sortOption) {
        case SortOption.employeeName:
          comparison = (profileA?['EMPNAME'] ?? '').compareTo(profileB?['EMPNAME'] ?? '');
          break;
        case SortOption.employeeNumber:
          comparison = (profileA?['EMPNO'] ?? '').compareTo(profileB?['EMPNO'] ?? '');
          break;
        case SortOption.reason:
          comparison = (a['REASON'] ?? '').compareTo(b['REASON'] ?? '');
          break;
        case SortOption.date:
        default:
          comparison = DateTime.parse(a['SHIFTDATE']).compareTo(DateTime.parse(b['SHIFTDATE']));
          break;
      }
      return _sortDirection == SortDirection.ascending ? comparison : -comparison;
    });
  }

  Future<void> _handleRequest(int attendanceId, bool isApproved) async {
    try {
      await supabase
          .from('attendance')
          .update({'APPROVAL_STATUS': isApproved ? '1' : '0'})
          .eq('ID', attendanceId);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Request has been ${isApproved ? 'approved' : 'declined'}.'), backgroundColor: Colors.green),
      );
      _fetchInitialRequests();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
    }
  }

  Future<void> _selectDateRange() async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      initialDateRange: _startDate != null && _endDate != null
          ? DateTimeRange(start: _startDate!, end: _endDate!)
          : null,
    );
    if (picked != null) {
      setState(() {
        _dateFilterMode = DateFilterMode.range;
        _startDate = picked.start;
        _endDate = picked.end;
      });
      _filterLocalData();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDarkMode ? Colors.black : const Color(0xFFF2F2F7),
      appBar: AppBar(
        title: const Text('Approve Requests', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: isDarkMode ? Colors.black : const Color(0xFFF2F2F7),
        elevation: 0,
      ),
      body: Column(
        children: [
          _buildControls(),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _errorMessage.isNotEmpty
                ? Center(child: Text(_errorMessage))
                : _filteredResults.isEmpty && !_isFetchingMore
                ? _buildNoResultsWidget()
                : RefreshIndicator(
              onRefresh: _fetchData,
              child: _viewMode == ViewMode.tiles && _searchMode == SearchMode.requests
                  ? _buildTilesView()
                  : _buildDetailView(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControls() {
    IconData icon;
    Color iconColor;
    String hintText;

    switch (_searchMode) {
      case SearchMode.team:
        icon = Icons.group;
        iconColor = Theme.of(context).primaryColor;
        hintText = 'Search Your Team...';
        break;
      case SearchMode.global:
        icon = Icons.public;
        iconColor = Colors.green;
        hintText = 'Global Employee Search...';
        break;
      case SearchMode.requests:
      default:
        icon = Icons.group_outlined;
        iconColor = Colors.grey;
        hintText = 'Search Pending Requests...';
        break;
    }

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextField(
            controller: _searchController,
            decoration: InputDecoration(
              hintText: hintText,
              prefixIcon: const Icon(Icons.search),
              suffixIcon: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_searchController.text.isNotEmpty)
                    IconButton(
                      icon: const Icon(Icons.clear, color: Colors.grey),
                      onPressed: () {
                        _searchController.clear();
                      },
                    ),
                  IconButton(
                    icon: Icon(icon, color: iconColor),
                    tooltip: 'Cycle Search Mode',
                    onPressed: _toggleSearchMode,
                  ),
                ],
              ),
              filled: true,
              fillColor: Theme.of(context).cardColor,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            ),
          ),
          if (_searchMode == SearchMode.requests) ...[
            const SizedBox(height: 12),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  ActionChip(
                    avatar: const Icon(Icons.date_range, size: 16),
                    label: Text(_dateFilterMode == DateFilterMode.range && _startDate != null && _endDate != null
                        ? '${DateFormat.yMMMd().format(_startDate!)} - ${DateFormat.yMMMd().format(_endDate!)}'
                        : 'Select Range'),
                    onPressed: _selectDateRange,
                  ),
                  const SizedBox(width: 8),
                  FilterChip(
                    label: const Text('Today'),
                    selected: _dateFilterMode == DateFilterMode.day,
                    onSelected: (selected) {
                      if (selected) {
                        final now = DateTime.now();
                        setState(() {
                          _dateFilterMode = DateFilterMode.day;
                          _startDate = DateTime(now.year, now.month, now.day);
                          _endDate = _startDate;
                        });
                        _filterLocalData();
                      }
                    },
                  ),
                  const SizedBox(width: 8),
                  FilterChip(
                    label: const Text('This Week'),
                    selected: _dateFilterMode == DateFilterMode.week,
                    onSelected: (selected) {
                      if (selected) {
                        final now = DateTime.now();
                        final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
                        setState(() {
                          _dateFilterMode = DateFilterMode.week;
                          _startDate = DateTime(startOfWeek.year, startOfWeek.month, startOfWeek.day);
                          _endDate = _startDate?.add(const Duration(days: 6));
                        });
                        _filterLocalData();
                      }
                    },
                  ),
                  const SizedBox(width: 8),
                  FilterChip(
                    label: const Text('This Month'),
                    selected: _dateFilterMode == DateFilterMode.month,
                    onSelected: (selected) {
                      if (selected) {
                        final now = DateTime.now();
                        setState(() {
                          _dateFilterMode = DateFilterMode.month;
                          _startDate = DateTime(now.year, now.month, 1);
                          _endDate = DateTime(now.year, now.month + 1, 0);
                        });
                        _filterLocalData();
                      }
                    },
                  ),
                  if (_dateFilterMode != DateFilterMode.none) ...[
                    const SizedBox(width: 8),
                    ActionChip(
                      avatar: const Icon(Icons.clear, size: 16),
                      label: const Text('Clear'),
                      onPressed: (){
                        setState(() {
                          _dateFilterMode = DateFilterMode.none;
                          _startDate = null;
                          _endDate = null;
                        });
                        _filterLocalData();
                      },
                    )
                  ]
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                SegmentedButton<ViewMode>(
                  segments: const <ButtonSegment<ViewMode>>[
                    ButtonSegment<ViewMode>(value: ViewMode.detail, icon: Icon(Icons.list)),
                    ButtonSegment<ViewMode>(value: ViewMode.tiles, icon: Icon(Icons.grid_view)),
                  ],
                  selected: <ViewMode>{_viewMode},
                  onSelectionChanged: (Set<ViewMode> newSelection) {
                    setState(() {
                      _viewMode = newSelection.first;
                    });
                  },
                ),
                const Spacer(),
                DropdownButton<SortOption>(
                  value: _sortOption,
                  underline: const SizedBox(),
                  items: const [
                    DropdownMenuItem(value: SortOption.date, child: Text('Date')),
                    DropdownMenuItem(value: SortOption.employeeName, child: Text('Name')),
                    DropdownMenuItem(value: SortOption.employeeNumber, child: Text('EMPNO')),
                    DropdownMenuItem(value: SortOption.reason, child: Text('Reason')),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _sortOption = value;
                        _filterLocalData();
                      });
                    }
                  },
                ),
                IconButton(
                  icon: Icon(_sortDirection == SortDirection.ascending ? Icons.arrow_upward : Icons.arrow_downward),
                  tooltip: 'Toggle Sort Order',
                  onPressed: () {
                    setState(() {
                      _sortDirection = _sortDirection == SortDirection.ascending ? SortDirection.descending : SortDirection.ascending;
                      _filterLocalData();
                    });
                  },
                ),
              ],
            )
          ]
        ],
      ),
    );
  }

  Widget _buildNoResultsWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.search_off, size: 60, color: Colors.grey),
            const SizedBox(height: 16),
            const Text('No Matches Found', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (_searchMode == SearchMode.requests) ...[
              const Text('Try searching your entire team instead.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                icon: const Icon(Icons.group),
                label: const Text('Enable Team Search'),
                onPressed: () => _toggleSearchMode(),
              )
            ] else if (_searchMode == SearchMode.team) ... [
              const Text('Try a global search across all employees.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                icon: const Icon(Icons.public),
                label: const Text('Enable Global Search'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                onPressed: () => _toggleSearchMode(),
              )
            ] else if (_searchMode == SearchMode.global && _searchController.text.length < 3) ...[
              const Text('Please enter at least 3 characters to start a global search.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
            ]
          ],
        ),
      ),
    );
  }

  Widget _buildDetailView() {
    return ListView.separated(
      controller: _scrollController,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      itemCount: _filteredResults.length + (_searchMode == SearchMode.requests && _hasMore ? 1 : 0),
      separatorBuilder: (context, index) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        if (index == _filteredResults.length) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 16.0),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        return _searchMode == SearchMode.requests
            ? _buildApprovalCard(_filteredResults[index])
            : _buildProfileCard(_filteredResults[index]);
      },
    );
  }

  Widget _buildTilesView() {
    return GridView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.8,
      ),
      itemCount: _filteredResults.length + (_searchMode == SearchMode.requests && _hasMore ? 1 : 0),
      itemBuilder: (context, index) {
        if (index == _filteredResults.length) {
          return const Center(child: CircularProgressIndicator());
        }
        return _buildApprovalTile(_filteredResults[index]);
      },
    );
  }

  Widget _buildApprovalCard(Map<String, dynamic> request) {
    final profile = request['profiles'] ?? {};
    final photoUrl = profile['PHOTO_URL'];
    final name = profile['EMPNAME'] ?? 'N/A';
    final empNo = profile['EMPNO'] ?? 'N/A';

    return InkWell(
      onTap: () => Navigator.push(context, CupertinoPageRoute(builder: (context) => TeamMemberProfilePage(teamMemberProfile: request))),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Material(
          color: Theme.of(context).cardColor,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(radius: 25, backgroundImage: (photoUrl != null && photoUrl.isNotEmpty) ? NetworkImage(photoUrl) : null, child: (photoUrl == null || photoUrl.isEmpty) ? const Icon(Icons.person) : null),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 2),
                          Text('EMPNO: $empNo', style: Theme.of(context).textTheme.bodySmall),
                        ],
                      ),
                    ),
                  ],
                ),
                const Divider(height: 24),
                Text('Request for: ${DateFormat.yMMMMd().format(DateTime.parse(request['SHIFTDATE']))}', style: const TextStyle(fontWeight: FontWeight.w500)),
                const SizedBox(height: 8),
                Text('Reason: ${request['REASON']}'),
                const SizedBox(height: 16),
                Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                  TextButton(onPressed: () => _handleRequest(request['ID'], false), child: const Text('Decline'), style: TextButton.styleFrom(foregroundColor: Colors.red)),
                  const SizedBox(width: 8),
                  ElevatedButton(onPressed: () => _handleRequest(request['ID'], true), child: const Text('Approve'), style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)))),
                ])
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildApprovalTile(Map<String, dynamic> request) {
    final profile = request['profiles'] ?? {};
    final photoUrl = profile['PHOTO_URL'];
    final name = profile['EMPNAME'] ?? 'N/A';
    final empNo = profile['EMPNO'] ?? 'N/A';

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () => Navigator.push(context, CupertinoPageRoute(builder: (context) => TeamMemberProfilePage(teamMemberProfile: request))),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 25,
                backgroundImage: (photoUrl != null && photoUrl.isNotEmpty) ? NetworkImage(photoUrl) : null,
                child: (photoUrl == null || photoUrl.isEmpty) ? const Icon(Icons.person) : null,
              ),
              const SizedBox(height: 8),
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold), textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
              Text(empNo, style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 4),
              Text(DateFormat.yMMMMd().format(DateTime.parse(request['SHIFTDATE'])), style: Theme.of(context).textTheme.bodySmall),
              const Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(icon: const Icon(Icons.close, color: Colors.red), onPressed: () => _handleRequest(request['ID'], false)),
                  IconButton(icon: const Icon(Icons.check, color: Colors.green), onPressed: () => _handleRequest(request['ID'], true)),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }


  Widget _buildProfileCard(Map<String, dynamic> profile) {
    final name = profile['EMPNAME'] ?? 'N/A';
    final empNo = profile['EMPNO'] ?? 'N/A';
    final photoUrl = profile['PHOTO_URL'];
    final empClass = profile['EMP_CLASS']?.toString() ?? 'N/A';
    final userId = profile['ID']; // UUID from profiles table

    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Material(
        color: Theme.of(context).cardColor,
        child: ListTile(
          leading: CircleAvatar(
            radius: 25,
            backgroundImage: photoUrl != null && photoUrl.isNotEmpty ? NetworkImage(photoUrl) : null,
            child: photoUrl == null || photoUrl.isEmpty ? const Icon(Icons.person) : null,
          ),
          title: Text(name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
          subtitle: Text('EMPNO: $empNo | Class: $empClass', style: Theme.of(context).textTheme.bodySmall),
          trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
          onTap: () {
            if (userId == null) return;
            if (_searchMode == SearchMode.global) {
              Navigator.push(context, CupertinoPageRoute(builder: (context) => GlobalMemberProfilePage(userId: userId)));
            } else {
              Navigator.push(context, CupertinoPageRoute(builder: (context) => TeamMemberProfilePage(teamMemberProfile: profile)));
            }
          },
        ),
      ),
    );
  }
}
