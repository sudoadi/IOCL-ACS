import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:myacs/main.dart';
import 'package:provider/provider.dart';
import 'package:myacs/providers/attendance_provider.dart';

class MyRegularizationsPage extends StatefulWidget {
  const MyRegularizationsPage({super.key});

  @override
  State<MyRegularizationsPage> createState() => _MyRegularizationsPageState();
}

class _MyRegularizationsPageState extends State<MyRegularizationsPage> {
  late Future<List<Map<String, dynamic>>> _requestsFuture;

  @override
  void initState() {
    super.initState();
    _requestsFuture = _fetchMyRequests();
  }

  Future<List<Map<String, dynamic>>> _fetchMyRequests() async {
    // Use the profile info from the provider
    final profile = Provider.of<AttendanceProvider>(context, listen: false).profile;
    if (profile == null || profile['EMPNO'] == null) {
      // Handle case where profile isn't loaded yet
      throw 'Your profile could not be loaded. Please try again.';
    }

    final empNo = profile['EMPNO'];

    final response = await supabase
        .from('attendance')
        .select()
        .eq('EMPNO', empNo)
        .not('REASON', 'is', null) // Fetch only records where a reason was submitted
        .order('SHIFTDATE', ascending: false);

    return List<Map<String, dynamic>>.from(response);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Regularization Requests'),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _requestsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('You have no regularization requests.'));
          }

          final requests = snapshot.data!;
          return ListView.builder(
            itemCount: requests.length,
            itemBuilder: (context, index) {
              final request = requests[index];
              return _buildRequestCard(request);
            },
          );
        },
      ),
    );
  }

  Widget _buildRequestCard(Map<String, dynamic> request) {
    final date = DateTime.parse(request['SHIFTDATE']);
    final reason = request['REASON'];
    final approvalStatus = request['APPROVAL_STATUS']?.toString();

    String statusText;
    Color statusColor;
    IconData statusIcon;

    if (approvalStatus == '1') {
      statusText = 'Approved';
      statusColor = Colors.green;
      statusIcon = Icons.check_circle;
    } else if (approvalStatus == '0') {
      statusText = 'Not Approved';
      statusColor = Colors.red;
      statusIcon = Icons.cancel;
    } else {
      statusText = 'Pending';
      statusColor = Colors.blue;
      statusIcon = Icons.hourglass_top_rounded;
    }

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: statusColor.withOpacity(0.1),
          child: Icon(statusIcon, color: statusColor),
        ),
        title: Text('Request for ${DateFormat.yMMMMd().format(date)}'),
        subtitle: Text('Reason: $reason', maxLines: 2, overflow: TextOverflow.ellipsis),
        trailing: Text(
          statusText,
          style: TextStyle(color: statusColor, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
