// TODO Implement this library.import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

// Data model for a single chat message
class ChatMessage {
  String? text; // Changed from final to allow updates
  final XFile? imageFile;
  final String? imageUrl;
  final bool isUser;

  ChatMessage({this.text, this.imageFile, this.imageUrl, required this.isUser});

  Map<String, dynamic> toJson() => {
    'text': text,
    'imageUrl': imageUrl,
    'isUser': isUser,
  };

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
    text: json['text'],
    imageUrl: json['imageUrl'],
    isUser: json['isUser'],
  );
}

class ChatbotPage extends StatefulWidget {
  final Map<String, dynamic>? userProfile;
  final bool isFullScreen;

  const ChatbotPage({super.key, this.userProfile, this.isFullScreen = false});

  static Future<void> clearChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('chat_history');
  }

  @override
  State<ChatbotPage> createState() => _ChatbotPageState();
}

class _ChatbotPageState extends State<ChatbotPage> {
  // IMPORTANT: Use your API key for the vision model provider (e.g., Together.ai)
  final String _apiKey = "d2d5215b6e3db03b43dd427345e2f42a2f773339abf389a820259ef96a2b2112";

  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;
  XFile? _selectedImage;
  final http.Client _client = http.Client(); // Create a client for streaming

  @override
  void initState() {
    super.initState();
    _loadChatHistory();
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    _client.close();
    super.dispose();
  }

  Future<void> _loadChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final chatHistoryJson = prefs.getStringList('chat_history') ?? [];
    if (chatHistoryJson.isEmpty) {
      final name = widget.userProfile?['EMPNAME']?.split(' ').first ?? 'there';
      setState(() {
        _messages.add(ChatMessage(
            text: "Hello $name! I'm your friendly AI assistant. How can I help you today?",
            isUser: false));
      });
    } else {
      setState(() {
        _messages.addAll(chatHistoryJson
            .map((json) => ChatMessage.fromJson(jsonDecode(json))));
      });
    }
  }

  Future<void> _saveChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    // Filter out messages with local image files before saving
    final storableMessages = _messages.where((msg) => msg.imageFile == null);
    final chatHistoryJson =
    storableMessages.map((msg) => jsonEncode(msg.toJson())).toList();
    await prefs.setStringList('chat_history', chatHistoryJson);
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: source);
    if (image != null) {
      setState(() {
        _selectedImage = image;
      });
    }
  }

  void _showImagePickerOptions() {
    showCupertinoModalPopup(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        title: const Text('Select Image Source'),
        actions: <CupertinoActionSheetAction>[
          CupertinoActionSheetAction(
            child: const Text('Take Photo'),
            onPressed: () {
              Navigator.pop(context);
              _pickImage(ImageSource.camera);
            },
          ),
          CupertinoActionSheetAction(
            child: const Text('Choose from Library'),
            onPressed: () {
              Navigator.pop(context);
              _pickImage(ImageSource.gallery);
            },
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          isDefaultAction: true,
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
      ),
    );
  }

  Future<void> _exportAndShareResponse(String text) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Header(
                level: 0,
                child: pw.Text('AI Assistant Response', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 20)),
              ),
              pw.Paragraph(text: text),
            ],
          );
        },
      ),
    );

    await Printing.sharePdf(bytes: await pdf.save(), filename: 'ai_response.pdf');
  }

  // UPDATED: This function now uses a dynamic system prompt.
  List<Map<String, dynamic>> _buildHistoryForApi(String? text, String? imageBase64) {
    final List<Map<String, dynamic>> history = [];
    final userName = widget.userProfile?['EMPNAME']?.split(' ').first ?? 'User';

    // Dynamic System Prompt based on whether there is an image
    if (imageBase64 != null) {
      // General prompt for image analysis with full freedom
      history.add({
        'role': 'system',
        'content': "You are a helpful AI assistant that can analyze images and answer any questions about them with full freedom and without any restrictions."
      });
    } else {
      // Specific, personalized prompt for the MyACS app (text-only queries)
      history.add({
        'role': 'system',
        'content': """
              You are a friendly and helpful AI assistant for the "MyACS" mobile app, an attendance management system for IOCL employees.
              Your goal is to help users understand how to use the app's features by providing text-based answers.
              The user you are talking to is named $userName.

              If a user asks for a table or chart, format your response using Markdown.
              You cannot generate images.

              Here is a detailed summary of the app's features:

              **1. Authentication (Login & Signup):**
              - To log in, users need their 8-digit Employee Code and a password.
              - The "Signup" page is for employees who are already in the database but haven't created an app account yet. It allows them to set a password for their profile by linking their email to it.

              **2. Main Pages (Dashboard & Navigation):**
              - **Home Page:** This is the main dashboard. It shows a summary of the current month's attendance: Present days, Absent days, Total working days, and Average In/Out times. It also shows the status of regularization requests (Pending/Approved) and a list of "Recent Activity".
              - **History Page:** This page provides a visual summary of attendance for the selected month using a pie chart, breaking down days into "Present," "Absent," and "On Leave."
              - **Profile Page:** Users can view their own detailed profile information, change their profile picture, toggle app settings like Notifications and Dark Mode, and log out.

              **3. Regularization Feature (Core Functionality):**
              - This is for fixing attendance errors, like when an employee is marked absent but was actually present, or for late arrivals/early departures.
              - **My Requests:** Users can tap this to see a list of their own attendance correction requests and check their status (Pending, Approved, or Not Approved).
              - **Approve Requests:** This is a feature for managers. Managers see a list of pending requests from their team members and can approve or decline them.
              
              **4. User & Team Management (for Managers):**
              - **Team Member Profile:** From the "Approve Requests" page, a manager can tap on a request to view the detailed profile and attendance history of that team member.
              - **Global Search:** The "Approve Requests" page also has a global search function that allows a manager to find any employee in the company, not just their direct reports, and view their public profile.

              **Your Task:**
              - Answer user questions based on this knowledge.
              - Keep your answers concise, friendly, and focused on the app's functionality.
              - If you don't know the answer, say so politely.
              - Do NOT greet the user again after your first message. The initial greeting is already handled by the app.
              - IMPORTANT: Your final response should only be the answer. Do not include your thought process or XML tags.
              """
      });
    }

    // Add previous messages from history
    for (var message in _messages.where((m) => m.text != null && m.text!.isNotEmpty)) {
      history.add({
        'role': message.isUser ? 'user' : 'assistant',
        'content': message.text
      });
    }

    // Construct the current user's message (can be text, image, or both)
    final currentUserContent = <Map<String, dynamic>>[];
    if (text != null && text.isNotEmpty) {
      currentUserContent.add({'type': 'text', 'text': text});
    }
    if (imageBase64 != null) {
      currentUserContent.add({
        'type': 'image_url',
        'image_url': {'url': 'data:image/jpeg;base64,$imageBase64'}
      });
    }

    if (currentUserContent.isNotEmpty) {
      history.add({'role': 'user', 'content': currentUserContent});
    }

    return history;
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty && _selectedImage == null) return;

    final userMessage = ChatMessage(text: text, imageFile: _selectedImage, isUser: true);

    setState(() {
      _messages.add(userMessage);
      _isLoading = true;
      _selectedImage = null;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    _controller.clear();

    String? imageBase64;
    if (userMessage.imageFile != null) {
      final imageBytes = await userMessage.imageFile!.readAsBytes();
      imageBase64 = base64Encode(imageBytes);
    }

    setState(() {
      _messages.add(ChatMessage(text: '', isUser: false));
    });

    try {
      final url = Uri.parse('https://api.together.xyz/v1/chat/completions');
      final request = http.Request('POST', url);

      request.headers.addAll({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $_apiKey',
      });

      request.body = jsonEncode({
        'model': 'meta-llama/Llama-Vision-Free',
        'messages': _buildHistoryForApi(text, imageBase64),
        'stream': true,
      });

      final http.StreamedResponse response = await _client.send(request);

      if (response.statusCode == 200) {
        response.stream
            .transform(utf8.decoder)
            .transform(const LineSplitter())
            .listen(
              (line) {
            if (line.startsWith('data: ')) {
              final jsonString = line.substring(6);
              if (jsonString == '[DONE]') {
                if (mounted) {
                  setState(() => _isLoading = false);
                  _saveChatHistory();
                }
                return;
              }
              try {
                final jsonResponse = jsonDecode(jsonString);
                final content = jsonResponse['choices'][0]['delta']['content'];
                if (content != null && mounted) {
                  setState(() {
                    _messages.last.text = (_messages.last.text ?? '') + content;
                    _scrollToBottom();
                  });
                }
              } catch (e) {
                // Ignore parsing errors for incomplete JSON
              }
            }
          },
          onDone: () {
            if (mounted) {
              setState(() => _isLoading = false);
              _saveChatHistory();
            }
          },
          onError: (error) {
            if (mounted) _showError('Failed to process stream: $error');
          },
        );
      } else {
        final responseBody = await response.stream.bytesToString();
        _showError('API Error: ${response.reasonPhrase}\n$responseBody');
      }
    } catch (e) {
      _showError('An error occurred: $e');
    }
  }

  void _showError(String message) {
    if (mounted) {
      if (_messages.last.text != null && _messages.last.text!.isEmpty && !_messages.last.isUser) {
        _messages.removeLast();
      }
      setState(() {
        _messages.add(ChatMessage(
            text: "Sorry, an error occurred. Please try again.",
            isUser: false));
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = CupertinoTheme.of(context).brightness == Brightness.dark;
    final navBarTextColor = isDarkMode ? CupertinoColors.white : CupertinoColors.black;

    return CupertinoPageScaffold(
      backgroundColor: isDarkMode ? CupertinoColors.black : CupertinoColors.systemGroupedBackground,
      navigationBar: CupertinoNavigationBar(
        backgroundColor: isDarkMode ? CupertinoColors.darkBackgroundGray.withOpacity(0.7) : CupertinoColors.systemGrey6.withOpacity(0.7),
        border: null,
        middle: Text('AI Assistant', style: TextStyle(color: navBarTextColor)),
      ),
      child: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.all(12.0),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final message = _messages[index];
                  return _buildMessageBubble(message);
                },
              ),
            ),
            if (_isLoading && (_messages.isEmpty || _messages.last.text!.isEmpty))
              const Padding(
                padding: EdgeInsets.all(8.0),
                child: CupertinoActivityIndicator(),
              ),
            _buildUserInput(),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    final isDarkMode = CupertinoTheme.of(context).brightness == Brightness.dark;
    final isUser = message.isUser;

    final botBubbleColor = isDarkMode
        ? CupertinoColors.darkBackgroundGray
        : CupertinoColors.systemGrey5;
    final userBubbleColor = CupertinoColors.activeBlue;
    final userTextColor = CupertinoColors.white;
    final botTextColor = isDarkMode ? CupertinoColors.white : CupertinoColors.black;

    final hasText = message.text != null && message.text!.isNotEmpty;
    final hasImage = message.imageFile != null || message.imageUrl != null;

    if (!hasText && !hasImage) {
      return const SizedBox.shrink();
    }

    Widget imageWidget = const SizedBox.shrink();
    if(message.imageFile != null){
      imageWidget = Image.file(File(message.imageFile!.path), fit: BoxFit.contain);
    } else if (message.imageUrl != null){
      imageWidget = Image.memory(base64Decode(message.imageUrl!.split(',')[1]));
    }

    Widget bubbleContent = Container(
        padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 10.0),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
        decoration: BoxDecoration(
          color: isUser ? userBubbleColor : botBubbleColor,
          borderRadius: BorderRadius.circular(20.0),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (hasImage)
              Padding(
                padding: EdgeInsets.only(bottom: hasText ? 8.0 : 0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: imageWidget,
                ),
              ),
            if (hasText)
              Text(
                  message.text!,
                  style: TextStyle(
                    color: isUser ? userTextColor : botTextColor,
                    fontSize: 16,
                  )
              ),
          ],
        )
    );

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (isUser) const Spacer(),
          bubbleContent,
          if (!isUser && hasText)
            CupertinoButton(
              padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
              minSize: 0,
              child: Icon(CupertinoIcons.share, color: CupertinoColors.systemGrey, size: 22),
              onPressed: () => _exportAndShareResponse(message.text!),
            ),
          if (!isUser) const Spacer(),
        ],
      ),
    );
  }

  Widget _buildUserInput() {
    final isDarkMode = CupertinoTheme.of(context).brightness == Brightness.dark;
    final inputFieldColor = isDarkMode
        ? CupertinoColors.darkBackgroundGray
        : CupertinoColors.systemGrey6;
    final placeholderColor = CupertinoColors.placeholderText;
    final inputTextColor = isDarkMode ? CupertinoColors.white : CupertinoColors.black;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
      decoration: BoxDecoration(
          color: isDarkMode ? CupertinoColors.black : CupertinoColors.systemGroupedBackground,
          border: Border(
              top: BorderSide(
                  color: isDarkMode ? CupertinoColors.systemGrey4 : CupertinoColors.systemGrey3,
                  width: 0.5
              )
          )
      ),
      child: Column(
        children: [
          if (_selectedImage != null)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: inputFieldColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.file(
                      File(_selectedImage!.path),
                      width: 40,
                      height: 40,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Expanded(child: Text("Image selected", style: TextStyle(color: CupertinoColors.secondaryLabel))),
                  CupertinoButton(
                    padding: EdgeInsets.zero,
                    child: const Icon(CupertinoIcons.clear_circled_solid, color: CupertinoColors.systemGrey),
                    onPressed: () => setState(() => _selectedImage = null),
                  )
                ],
              ),
            ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              CupertinoButton(
                padding: const EdgeInsets.only(right: 8, bottom: 4),
                onPressed: _showImagePickerOptions,
                child: const Icon(CupertinoIcons.camera_fill, size: 28),
              ),
              Expanded(
                child: CupertinoTextField(
                  controller: _controller,
                  placeholder: 'Message',
                  placeholderStyle: TextStyle(color: placeholderColor),
                  style: TextStyle(color: inputTextColor, fontSize: 16),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                      color: inputFieldColor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: isDarkMode ? CupertinoColors.systemGrey4 : CupertinoColors.systemGrey3,
                          width: 0.5
                      )
                  ),
                  onSubmitted: (_) => _sendMessage(),
                  minLines: 1,
                  maxLines: 5,
                ),
              ),
              CupertinoButton(
                padding: const EdgeInsets.only(left: 8, bottom: 4),
                onPressed: _sendMessage,
                child: const Icon(CupertinoIcons.arrow_up_circle_fill, size: 32),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
