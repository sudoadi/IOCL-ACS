import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:myacs/main.dart';
import 'package:myacs/pages/auth/login_page.dart';
import 'package:myacs/theme_provider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool _notificationsEnabled = true;
  Map<String, dynamic>? _profile;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _fetchProfile();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
    });
  }

  Future<void> _fetchProfile() async {
    if (!mounted) return;
    setState(() { _isLoading = true; });
    try {
      final userId = supabase.auth.currentUser!.id;
      // Fetch all columns from the profiles table
      final data = await supabase.from('profiles').select('*').eq('ID', userId).single();
      if (mounted) {
        setState(() {
          _profile = data;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        _showError("Error fetching profile: $e");
        setState(() { _isLoading = false; });
      }
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), backgroundColor: Colors.red));
  }

  void _showSuccess(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), backgroundColor: Colors.green));
  }

  String _getInitials(String name) {
    if (name.trim().isEmpty) return '?';
    List<String> names = name.trim().split(' ');
    String initials = '';
    int numWords = names.length > 1 ? 2 : 1;
    for (int i = 0; i < numWords; i++) {
      if (names[i].isNotEmpty) {
        initials += names[i][0].toUpperCase();
      }
    }
    return initials.isEmpty ? '?' : initials;
  }

  Future<void> _pickAndUploadImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 50);

    if (image != null) {
      final bool? confirmUpload = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Confirm New Avatar'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Do you want to upload this image as your new avatar?'),
              const SizedBox(height: 20),
              CircleAvatar(
                radius: 60,
                backgroundImage: FileImage(File(image.path)),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Upload'),
            ),
          ],
        ),
      );

      if (confirmUpload == true) {
        setState(() { _isLoading = true; });
        try {
          final userId = supabase.auth.currentUser!.id;
          final imageBytes = await image.readAsBytes();
          final fileName = '$userId/avatar.png';

          await supabase.storage.from('avatars').uploadBinary(
            fileName,
            imageBytes,
            fileOptions: const FileOptions(upsert: true, contentType: 'image/png'),
          );
          final imageUrl = supabase.storage.from('avatars').getPublicUrl(fileName);

          // Updated to use PHOTO_URL
          await supabase.from('profiles').update({'PHOTO_URL': imageUrl}).eq('ID', userId);
          _showSuccess("Profile picture updated!");
          await _fetchProfile();
        } catch (e) {
          _showError("Error uploading image: $e");
        } finally {
          if(mounted){
            setState(() { _isLoading = false; });
          }
        }
      }
    }
  }

  Future<void> _deleteAvatar() async {
    final bool? confirmDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Deletion'),
        content: const Text('Are you sure you want to remove your profile picture?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if(confirmDelete == true) {
      setState(() { _isLoading = true; });
      try {
        final userId = supabase.auth.currentUser!.id;
        await supabase.storage.from('avatars').remove(['$userId/avatar.png']);

        // Updated to use PHOTO_URL
        await supabase.from('profiles').update({'PHOTO_URL': null}).eq('ID', userId);
        _showSuccess("Profile picture removed!");
        await _fetchProfile();
      } catch (e) {
        _showError("Error removing image: $e");
      } finally {
        if(mounted){
          setState(() { _isLoading = false; });
        }
      }
    }
  }

  Future<void> _logout() async {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Confirm Logout'),
          content: const Text('Are you sure you want to log out?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                await supabase.auth.signOut();
                if (mounted) {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => const LoginPage()),
                        (route) => false,
                  );
                }
              },
              child: const Text('Logout', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        automaticallyImplyLeading: false,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
        onRefresh: _fetchProfile,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 100),
          children: [
            _buildProfileHeader(),
            const SizedBox(height: 30),
            _buildJobDetailsSection(),
            const SizedBox(height: 30),
            _buildSettingsSection(themeProvider),
            const SizedBox(height: 30),
            _buildLogoutButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileHeader() {
    // Updated to use PHOTO_URL
    final avatarUrl = _profile?['PHOTO_URL'];
    ImageProvider<Object>? backgroundImageProvider;
    if (avatarUrl != null && (avatarUrl as String).isNotEmpty) {
      backgroundImageProvider = NetworkImage(avatarUrl);
    }

    final empName = _profile?['EMPNAME'];
    final desgn = _profile?['DESGN'];
    final empNo = _profile?['EMPNO'];
    final email = _profile?['EMAIL'];
    final location = _profile?['LOCATION'];
    final controllingOfficer = _profile?['CONTROLLING_OFFICER'];

    return Column(
      children: [
        Stack(
          children: [
            CircleAvatar(
              radius: 70,
              backgroundColor: Theme.of(context).colorScheme.surface.withOpacity(0.1),
              backgroundImage: backgroundImageProvider,
              child: backgroundImageProvider == null ? Icon(Icons.person, size: 70, color: Colors.grey.shade600) : null,
            ),
            Positioned(
              bottom: 0,
              right: 0,
              child: CircleAvatar(
                radius: 22,
                backgroundColor: Theme.of(context).primaryColor,
                child: IconButton(
                  icon: const Icon(Icons.camera_alt, color: Colors.white, size: 22),
                  onPressed: _pickAndUploadImage,
                ),
              ),
            ),
            if (avatarUrl != null && (avatarUrl as String).isNotEmpty)
              Positioned(
                bottom: 0,
                left: 0,
                child: CircleAvatar(
                  radius: 22,
                  backgroundColor: Colors.red.shade400,
                  child: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.white, size: 22),
                    onPressed: _deleteAvatar,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 20),
        if (empName != null && empName.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: Text(empName, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          ),
        if (desgn != null && desgn.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: Text(desgn, style: TextStyle(fontSize: 18, color: Theme.of(context).primaryColor), textAlign: TextAlign.center),
          ),
        if (empNo != null && empNo.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4.0),
            child: _buildInfoChip(Icons.badge_outlined, 'EMP NO: $empNo'),
          ),
        if (email != null && email.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4.0),
            child: _buildInfoChip(Icons.email_outlined, email),
          ),
        if (location != null && location.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4.0),
            child: _buildInfoChip(Icons.location_on_outlined, location),
          ),
        if (controllingOfficer != null && controllingOfficer.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4.0),
            child: _buildInfoChip(Icons.person_outline, 'Reporting to: $controllingOfficer'),
          ),
      ],
    );
  }

  Widget _buildInfoChip(IconData icon, String text) {
    return Chip(
      avatar: Icon(icon, size: 16, color: Colors.grey.shade600),
      label: Text(text, style: TextStyle(color: Colors.grey.shade400)),
      backgroundColor: Theme.of(context).cardColor,
    );
  }

  Widget _buildJobDetailsSection() {
    // Helper to format dates
    String formatDate(String? dateStr) {
      if (dateStr == null) return 'N/A';
      try {
        return DateFormat.yMMMd().format(DateTime.parse(dateStr));
      } catch (e) {
        return 'N/A';
      }
    }

    final grade = _profile?['GRADE'];
    final sapDept = _profile?['SAP_DEPT'];
    final section = _profile?['SECTION_CODE_TEXT'];
    final dojCorp = formatDate(_profile?['DOJ_CORP']);
    final dojCurrentGrade = formatDate(_profile?['DOJ_CURRENT_GRADE']);

    final details = <Widget>[
      if (grade != null && grade.isNotEmpty)
        _buildDetailRow('Grade', grade),
      if (sapDept != null && sapDept.isNotEmpty)
        _buildDetailRow('Department', sapDept),
      if (section != null && section.isNotEmpty)
        _buildDetailRow('Section', section),
      if (dojCorp != 'N/A')
        _buildDetailRow('Joined Date', dojCorp),
    ];

    if (details.isEmpty) {
      return const SizedBox.shrink();
    }

    return _buildSectionContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Job Details", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const Divider(height: 20),
          ...details,
        ],
      ),
    );
  }

  Widget _buildDetailRow(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: TextStyle(color: Colors.grey.shade400)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildSettingsSection(ThemeProvider themeProvider) {
    return _buildSectionContainer(
      child: Column(
        children: [
          _buildSettingsRow(
            icon: Icons.notifications_outlined,
            title: 'Notifications',
            trailing: Switch(
              value: _notificationsEnabled,
              onChanged: (value) async {
                final prefs = await SharedPreferences.getInstance();
                await prefs.setBool('notifications_enabled', value);
                setState(() {
                  _notificationsEnabled = value;
                });
              },
            ),
          ),
          const Divider(),
          _buildSettingsRow(
            icon: Icons.dark_mode_outlined,
            title: 'Dark Mode',
            trailing: Switch(
              value: themeProvider.themeMode == ThemeMode.dark,
              onChanged: (value) {
                themeProvider.toggleTheme(value);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionContainer({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(15),
      ),
      child: child,
    );
  }

  Widget _buildSettingsRow({required IconData icon, required String title, required Widget trailing}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, color: Colors.grey.shade400),
          const SizedBox(width: 16),
          Text(title, style: const TextStyle(fontSize: 16)),
          const Spacer(),
          trailing,
        ],
      ),
    );
  }

  Widget _buildLogoutButton() {
    return ElevatedButton.icon(
      onPressed: _logout,
      icon: const Icon(Icons.logout),
      label: const Text('Logout'),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.red.shade400,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 16),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }
}
