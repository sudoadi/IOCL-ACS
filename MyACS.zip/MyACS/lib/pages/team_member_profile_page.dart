import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:month_picker_dialog/month_picker_dialog.dart';
import 'package:myacs/main.dart';
import 'package:myacs/widgets/profile_header.dart';
import 'package:myacs/widgets/stats_grid.dart';
import 'package:myacs/widgets/recent_activity_list.dart';

class TeamMemberProfilePage extends StatefulWidget {
  final Map<String, dynamic> teamMemberProfile;

  const TeamMemberProfilePage({super.key, required this.teamMemberProfile});

  @override
  State<TeamMemberProfilePage> createState() => _TeamMemberProfilePageState();
}

class _TeamMemberProfilePageState extends State<TeamMemberProfilePage> {
  bool _isLoading = true;
  List<Map<String, dynamic>> _attendanceRecords = [];
  DateTime _selectedDate = DateTime.now();

  // Stats for the viewed profile
  int _presentDays = 0;
  int _absentDays = 0;
  String _avgInTime = "N/A";
  String _avgOutTime = "N/A";
  int _totalWorkingDays = 0;

  @override
  void initState() {
    super.initState();
    _fetchAttendanceForMonth(_selectedDate);
  }

  // --- MODIFIED: Helper function to safely extract profile data ---
  Map<String, dynamic> get _profileData {
    // Data can be a direct profile record or nested inside an attendance record.
    return widget.teamMemberProfile['profiles'] ?? widget.teamMemberProfile;
  }

  Future<void> _fetchAttendanceForMonth(DateTime date) async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _selectedDate = date; // Update selected date
    });

    // --- MODIFIED: Use the helper to get the employee number.
    final empNo = _profileData['EMPNO'];
    if (empNo == null) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Employee number not found.'), backgroundColor: Colors.red));
      }
      return;
    }

    final firstDayOfMonth = DateTime(date.year, date.month, 1);
    final lastDayOfMonth = DateTime(date.year, date.month + 1, 0);

    try {
      final response = await supabase
          .from('attendance')
          .select()
          .eq('EMPNO', empNo)
          .gte('SHIFTDATE', firstDayOfMonth.toIso8601String())
          .lte('SHIFTDATE', lastDayOfMonth.toIso8601String())
          .order('SHIFTDATE', ascending: false);

      if (mounted) {
        setState(() {
          _attendanceRecords = List<Map<String, dynamic>>.from(response);
          _calculateMonthlyStats();
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error fetching attendance: $e'), backgroundColor: Colors.red));
      }
    }
  }

  void _calculateMonthlyStats() {
    int present = 0;
    int absent = 0;

    for (final record in _attendanceRecords) {
      final dayInfo = record['DAYINFO']?.toString().toUpperCase() ?? '';

      if (dayInfo != 'SATURDAY' && dayInfo != 'SUNDAY' && dayInfo.contains('WEEKLY OFF') == false) {
        final status = record['STATUS']?.toString().toUpperCase() ?? '';
        if (status == 'PRESENT') {
          present++;
        } else if (status == 'ABSENT') {
          absent++;
        }
      }
    }

    final checkInTimes = _attendanceRecords
        .where((rec) => rec['INSWIPE'] != null && rec['STATUS'] == 'PRESENT')
        .map((rec) => DateTime.parse(rec['INSWIPE']))
        .toList();

    if (checkInTimes.isNotEmpty) {
      double totalSeconds = checkInTimes.fold(0, (p, e) => p + (e.hour * 3600 + e.minute * 60 + e.second));
      _avgInTime = DateFormat('h:mm a').format(DateTime(2000).add(Duration(seconds: (totalSeconds / checkInTimes.length).round())));
    } else {
      _avgInTime = "N/A";
    }

    final checkOutTimes = _attendanceRecords
        .where((rec) => rec['OUTSWIPE'] != null && rec['STATUS'] == 'PRESENT')
        .map((rec) => DateTime.parse(rec['OUTSWIPE']))
        .toList();

    if (checkOutTimes.isNotEmpty) {
      double totalSeconds = checkOutTimes.fold(0, (p, e) => p + (e.hour * 3600 + e.minute * 60 + e.second));
      _avgOutTime = DateFormat('h:mm a').format(DateTime(2000).add(Duration(seconds: (totalSeconds / checkOutTimes.length).round())));
    } else {
      _avgOutTime = "N/A";
    }

    setState(() {
      _presentDays = present;
      _absentDays = absent;
      _totalWorkingDays = present + absent;
    });
  }

  Future<void> _selectMonth(BuildContext context) async {
    final DateTime? picked = await showMonthPicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null && (picked.month != _selectedDate.month || picked.year != _selectedDate.year)) {
      _fetchAttendanceForMonth(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    // --- MODIFIED: Adapt the profile data to what ProfileHeader expects using the helper.
    final profileForHeader = {
      'EMPNAME': _profileData['EMPNAME'],
      'PHOTO_URL': _profileData['PHOTO_URL'], // Use PHOTO_URL
    };

    return Scaffold(
      appBar: AppBar(
        title: Text(profileForHeader['EMPNAME'] ?? 'Profile'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
        onRefresh: () => _fetchAttendanceForMonth(_selectedDate),
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            ProfileHeader(profile: profileForHeader),
            const SizedBox(height: 30),
            _buildMonthSelector(context),
            const SizedBox(height: 20),
            StatsGrid(
              presentDays: _presentDays,
              absentDays: _absentDays,
              totalWorkingDays: _totalWorkingDays,
              avgInTime: _avgInTime,
              avgOutTime: _avgOutTime,
              pendingRegularizations: 0, // Not applicable in read-only view
              approvedRegularizations: 0, // Not applicable
              onPresentLongPress: () {}, // Read-only
              onAbsentLongPress: () {}, // Read-only
              onRegularizationLongPress: () {}, // Read-only
            ),
            const SizedBox(height: 30),
            Text("Recent Activity", style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            RecentActivityList(
              attendanceRecords: _attendanceRecords,
              onRecordLongPress: (ctx, record) {
                // This is a read-only view, so no action is needed here.
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMonthSelector(BuildContext context) {
    bool isCurrentMonth = _selectedDate.year == DateTime.now().year && _selectedDate.month == DateTime.now().month;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text("Attendance", style: Theme.of(context).textTheme.titleLarge),
        Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), spreadRadius: 1, blurRadius: 5)],
          ),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.chevron_left),
                onPressed: () => _fetchAttendanceForMonth(DateTime(_selectedDate.year, _selectedDate.month - 1, 1)),
              ),
              GestureDetector(
                onTap: () => _selectMonth(context),
                child: Text(DateFormat('MMMM yyyy').format(_selectedDate), style: const TextStyle(fontWeight: FontWeight.w600)),
              ),
              IconButton(
                icon: const Icon(Icons.chevron_right),
                onPressed: isCurrentMonth ? null : () => _fetchAttendanceForMonth(DateTime(_selectedDate.year, _selectedDate.month + 1, 1)),
              ),
            ],
          ),
        )
      ],
    );
  }
}
