import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:myacs/pages/my_regularizations_page.dart';
import 'package:myacs/pages/approve_regularizations_page.dart';
import 'chatbot_page.dart'; // Import the chatbot page

class FloatingNavBar extends StatefulWidget {
  final int activeIndex;
  final Function(int) onTabSelected;
  // --- NEW: Accepting user profile data ---
  final Map<String, dynamic>? userProfile;

  const FloatingNavBar({
    super.key,
    required this.activeIndex,
    required this.onTabSelected,
    this.userProfile,
  });

  @override
  State<FloatingNavBar> createState() => _FloatingNavBarState();
}

class _FloatingNavBarState extends State<FloatingNavBar>
    with TickerProviderStateMixin {
  bool _isMenuOpen = false;
  bool _isAiMenuOpen = false;
  bool _isAiHelpActive = false;

  late AnimationController _animationController;
  late Animation<double> _animation;
  late AnimationController _aiAnimationController;
  late Animation<double> _aiAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _animation =
        CurvedAnimation(parent: _animationController, curve: Curves.easeOutBack);

    _aiAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _aiAnimation =
        CurvedAnimation(parent: _aiAnimationController, curve: Curves.easeOutBack);
  }

  @override
  void dispose() {
    _animationController.dispose();
    _aiAnimationController.dispose();
    super.dispose();
  }

  void _openChatbotDialog(BuildContext context) {
    HapticFeedback.lightImpact();
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
      barrierColor: Colors.black.withOpacity(0.6),
      transitionDuration: const Duration(milliseconds: 400),
      pageBuilder: (BuildContext buildContext, Animation<double> animation,
          Animation<double> secondaryAnimation) {
        return Center(
          child: Material(
            borderRadius: BorderRadius.circular(20),
            child: SizedBox(
              height: MediaQuery.of(context).size.height * 0.75,
              width: MediaQuery.of(context).size.width * 0.9,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                // --- UPDATED: Passing user profile to the chatbot ---
                child: ChatbotPage(userProfile: widget.userProfile),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        return ScaleTransition(
          scale: CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutBack,
          ),
          child: child,
        );
      },
    ).then((_) {
      setState(() {
        _isAiHelpActive = false;
      });
    });
  }

  void _showClearHistoryDialog() {
    HapticFeedback.mediumImpact();
    showCupertinoModalPopup(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        title: const Text('Clear Chat History'),
        message: const Text('Are you sure you want to delete the current chat session?'),
        actions: <CupertinoActionSheetAction>[
          CupertinoActionSheetAction(
            isDestructiveAction: true,
            onPressed: () {
              Navigator.pop(context);
              ChatbotPage.clearChatHistory();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Chat history cleared.'),
                  backgroundColor: Colors.green,
                ),
              );
            },
            child: const Text('Clear History'),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          isDefaultAction: true,
          onPressed: () {
            Navigator.pop(context);
          },
          child: const Text('Cancel'),
        ),
      ),
    );
  }

  void _toggleAiMenu() {
    HapticFeedback.mediumImpact();
    setState(() {
      _isAiMenuOpen = !_isAiMenuOpen;
      if (_isAiMenuOpen) {
        _aiAnimationController.forward();
        if (_isMenuOpen) {
          _animationController.reverse();
          _isMenuOpen = false;
        }
      } else {
        _aiAnimationController.reverse();
      }
    });
  }

  void _toggleMenu(int index) {
    HapticFeedback.lightImpact();
    if (index == 4) {
      setState(() {
        _isAiHelpActive = true;
        if (_isMenuOpen) _toggleMenu(2);
        if (_isAiMenuOpen) _toggleAiMenu();
      });
      _openChatbotDialog(context);
      return;
    }

    if (_isAiHelpActive) {
      setState(() => _isAiHelpActive = false);
    }
    if (_isAiMenuOpen) _toggleAiMenu();

    if (index == 2) {
      setState(() {
        _isMenuOpen = !_isMenuOpen;
        if (_isMenuOpen) {
          _animationController.forward();
        } else {
          _animationController.reverse();
        }
      });
    } else {
      if (_isMenuOpen) {
        _animationController.reverse();
        setState(() => _isMenuOpen = false);
      }
      widget.onTabSelected(index);
    }
  }

  Widget _buildPopupMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Icon(icon,
                  color: Theme.of(context).textTheme.bodySmall?.color,
                  size: 22),
              const SizedBox(width: 16),
              Text(label,
                  style: TextStyle(
                      color: Theme.of(context).textTheme.bodySmall?.color,
                      fontWeight: FontWeight.bold,
                      fontSize: 16)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      alignment: Alignment.bottomCenter,
      children: [
        Positioned(
          bottom: 20,
          left: 20,
          right: 20,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                height: 70,
                decoration: BoxDecoration(
                    color: Theme.of(context).cardColor.withOpacity(0.85),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(
                        color:
                        Theme.of(context).dividerColor.withOpacity(0.2))),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                        minWidth: MediaQuery.of(context).size.width - 40),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        _buildBottomNavItem(context, 0, Icons.home, "Home"),
                        _buildBottomNavItem(context, 1, Icons.history, "History"),
                        _buildBottomNavItem(
                            context, 2, Icons.rule_folder_outlined, "Regularize"),
                        _buildBottomNavItem(context, 3, Icons.person, "Profile"),
                        _buildBottomNavItem(
                          context,
                          4,
                          CupertinoIcons.sparkles,
                          "AI Help",
                          onLongPress: _toggleAiMenu,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 105,
          child: IgnorePointer(
            ignoring: !_isMenuOpen,
            child: ScaleTransition(
              scale: _animation,
              alignment: const Alignment(0.25, 1.0),
              child: FadeTransition(
                opacity: _animation,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                    child: Container(
                      width: 220,
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor.withOpacity(0.85),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: Theme.of(context)
                                .dividerColor
                                .withOpacity(0.2)),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildPopupMenuItem(
                            icon: Icons.person_search_outlined,
                            label: "My Requests",
                            onTap: () {
                              _toggleMenu(2);
                              Navigator.push(
                                  context,
                                  CupertinoPageRoute(
                                      builder: (context) =>
                                      const MyRegularizationsPage()));
                            },
                          ),
                          const Divider(height: 1, indent: 20, endIndent: 20),
                          _buildPopupMenuItem(
                            icon: Icons.checklist_rtl_outlined,
                            label: "Approve",
                            onTap: () {
                              _toggleMenu(2);
                              Navigator.push(
                                  context,
                                  CupertinoPageRoute(
                                      builder: (context) =>
                                      const ApproveRegularizationsPage()));
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 105,
          right: 20,
          child: IgnorePointer(
            ignoring: !_isAiMenuOpen,
            child: ScaleTransition(
              scale: _aiAnimation,
              alignment: Alignment.bottomRight,
              child: FadeTransition(
                opacity: _aiAnimation,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                    child: Container(
                      width: 180,
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor.withOpacity(0.85),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: Theme.of(context)
                                .dividerColor
                                .withOpacity(0.2)),
                      ),
                      child: _buildPopupMenuItem(
                        icon: CupertinoIcons.trash,
                        label: "Clear Chat",
                        onTap: () {
                          _toggleAiMenu();
                          _showClearHistoryDialog();
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBottomNavItem(
      BuildContext context,
      int index,
      IconData icon,
      String label, {
        VoidCallback? onLongPress,
      }) {
    final bool isActive = (widget.activeIndex == index) ||
        (index == 2 && _isMenuOpen) ||
        (index == 4 && _isAiHelpActive);

    final color = isActive
        ? Theme.of(context).primaryColor
        : Theme.of(context).textTheme.bodySmall?.color?.withOpacity(0.7);

    return GestureDetector(
      onTap: () => _toggleMenu(index),
      onLongPress: onLongPress,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
        width: isActive ? 100 : 55,
        height: 50,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: isActive
              ? Theme.of(context).primaryColor.withOpacity(0.15)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(25),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 28),
            if (isActive) ...[
              const SizedBox(width: 4),
              Flexible(
                child: AnimatedOpacity(
                  opacity: isActive ? 1.0 : 0.0,
                  duration: const Duration(milliseconds: 200),
                  child: Text(
                    label,
                    style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.bold,
                        fontSize: 14),
                    maxLines: 1,
                    softWrap: false,
                    overflow: TextOverflow.clip,
                  ),
                ),
              ),
            ]
          ],
        ),
      ),
    );
  }
}
