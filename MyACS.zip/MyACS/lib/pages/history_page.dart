import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:myacs/providers/attendance_provider.dart'; // <-- FIX: Added this import
import 'package:provider/provider.dart';

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Consume data from the provider
    final attendanceProvider = Provider.of<AttendanceProvider>(context);
    final selectedDate = attendanceProvider.selectedDate;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Attendance for ${DateFormat('MMMM yyyy').format(selectedDate)}',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false, // No back button
      ),
      body: attendanceProvider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : Center(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24.0, 24.0, 24.0, 100.0), // Padding for nav bar
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 250,
                child: PieChart(
                  PieChartData(
                    sections: _buildChartSections(context, attendanceProvider),
                    centerSpaceRadius: 70,
                    sectionsSpace: 2,
                  ),
                ),
              ),
              const SizedBox(height: 40),
              _buildLegend(context, attendanceProvider),
            ],
          ),
        ),
      ),
    );
  }

  List<PieChartSectionData> _buildChartSections(BuildContext context, AttendanceProvider provider) {
    final sections = <PieChartSectionData>[];
    final present = provider.presentDays;
    final absent = provider.absentDays;
    final leave = provider.leaveDays;
    final double total = (present + absent + leave).toDouble();

    if (total == 0) {
      return [
        PieChartSectionData(
          color: Colors.grey[300],
          value: 1,
          title: 'No Data',
          radius: 50,
          titleStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.grey),
        ),
      ];
    }

    void addSection(double value, Color color) {
      if (value > 0) {
        sections.add(
          PieChartSectionData(
            color: color,
            value: value,
            title: '${((value / total) * 100).toStringAsFixed(0)}%',
            radius: 60,
            titleStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
          ),
        );
      }
    }

    addSection(present.toDouble(), Colors.green);
    addSection(absent.toDouble(), Colors.red);
    addSection(leave.toDouble(), Colors.orange);

    return sections;
  }

  Widget _buildLegend(BuildContext context, AttendanceProvider provider) {
    return Column(
      children: [
        _buildLegendItem(Colors.green, 'Present', provider.presentDays.toString()),
        const SizedBox(height: 12),
        _buildLegendItem(Colors.red, 'Absent', provider.absentDays.toString()),
        const SizedBox(height: 12),
        _buildLegendItem(Colors.orange, 'On Leave', provider.leaveDays.toString()),
      ],
    );
  }

  Widget _buildLegendItem(Color color, String title, String value) {
    return Row(
      children: [
        Container(width: 16, height: 16, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 12),
        Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
        const Spacer(),
        Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ],
    );
  }
}
