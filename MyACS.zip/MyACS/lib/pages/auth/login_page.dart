import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:myacs/main.dart';
import 'package:myacs/pages/main_page.dart';
import 'package:myacs/pages/auth/signup_page.dart';
import 'package:myacs/theme_provider.dart';
import 'package:pinput/pinput.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

enum ButtonState { idle, loading, success, error }
enum ErrorType { none, validation, auth }

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with SingleTickerProviderStateMixin {
  final _employeeCodeController = TextEditingController();
  final _passwordController = TextEditingController();
  final _passwordFocusNode = FocusNode();
  bool _isBlinkingRed = false;
  bool _isBlinkingGreen = false;
  late AnimationController _animationController;
  ButtonState _buttonState = ButtonState.idle;
  String? _errorMessage;
  ErrorType _errorType = ErrorType.none;
  bool _isPasswordVisible = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );

    _animationController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        if (_buttonState == ButtonState.success) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const MainPage()),
          );
        } else if (_buttonState == ButtonState.error) {
          Future.delayed(const Duration(seconds: 2), () {
            if (mounted) {
              _animationController.reset();
              setState(() {
                _buttonState = ButtonState.idle;
                _errorMessage = null;
                _errorType = ErrorType.none;
              });
            }
          });
        }
      }
    });

    _passwordFocusNode.addListener(_onPasswordFocus);
  }

  @override
  void dispose() {
    _animationController.dispose();
    _employeeCodeController.dispose();
    _passwordController.dispose();
    _passwordFocusNode.removeListener(_onPasswordFocus);
    _passwordFocusNode.dispose();
    super.dispose();
  }

  void _onPasswordFocus() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (!mounted) return;
      final currentCode = _employeeCodeController.text;
      if (_passwordFocusNode.hasFocus &&
          currentCode.isNotEmpty &&
          currentCode.length < 8) {
        HapticFeedback.heavyImpact();
        Future.delayed(const Duration(milliseconds: 150), HapticFeedback.heavyImpact);

        final suggestedCode = currentCode.padLeft(8, '0');

        setState(() => _isBlinkingRed = true);

        Future.delayed(const Duration(milliseconds: 400), () {
          if (mounted) {
            setState(() {
              _isBlinkingRed = false;
              _employeeCodeController.text = suggestedCode;
              _isBlinkingGreen = true;
            });

            Future.delayed(const Duration(milliseconds: 800), () {
              if (mounted) {
                setState(() => _isBlinkingGreen = false);
              }
            });
          }
        });
      }
    });
  }

  void _handleError(String message, ErrorType type) {
    if (mounted) {
      setState(() {
        _buttonState = ButtonState.error;
        _errorMessage = message;
        _errorType = type;
      });
      _animationController.forward();
    }
  }

  Future<void> _signIn() async {
    if (_buttonState != ButtonState.idle) return;

    setState(() {
      _errorMessage = null;
      _errorType = ErrorType.none;
    });

    if (_employeeCodeController.text.length < 8) {
      _handleError("Please enter a valid 8-digit Employee Code.", ErrorType.validation);
      return;
    }
    if (_passwordController.text.isEmpty) {
      _handleError("Please enter your Password.", ErrorType.validation);
      return;
    }

    setState(() => _buttonState = ButtonState.loading);

    try {
      final response = await supabase.rpc('get_email_for_employee_code', params: {
        'emp_code': _employeeCodeController.text.trim(),
      });

      final email = response as String?;

      if (email == null || email.isEmpty) {
        throw const AuthException('Invalid login credentials.');
      }

      await supabase.auth.signInWithPassword(
        email: email,
        password: _passwordController.text.trim(),
      );

      setState(() => _buttonState = ButtonState.success);
      _animationController.forward();
    } on AuthException {
      _handleError("Invalid Employee Code or Password.", ErrorType.auth);
    } catch (error) {
      _handleError("An unexpected error occurred.", ErrorType.auth);
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.themeMode == ThemeMode.dark;

    final defaultPinTheme = PinTheme(
      width: 40,
      height: 45,
      textStyle: TextStyle(fontSize: 20, color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w600),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border.all(color: Theme.of(context).dividerColor),
        borderRadius: BorderRadius.circular(8),
      ),
    );

    final greenBlinkTheme = defaultPinTheme.copyWith(
        decoration: defaultPinTheme.decoration!.copyWith(border: Border.all(color: Colors.green, width: 2)));
    final redBlinkTheme = defaultPinTheme.copyWith(
        decoration: defaultPinTheme.decoration!.copyWith(border: Border.all(color: Colors.red, width: 2)));

    return Scaffold(
      body: Stack(
        children: [
          SafeArea(
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Theme.of(context).colorScheme.surface,
                    Theme.of(context).scaffoldBackgroundColor,
                  ],
                ),
              ),
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const SizedBox(height: 60),
                      Image.network(
                        'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Indian_Oil_Logo.svg/512px-Indian_Oil_Logo.svg.png',
                        height: 80,
                        // FIX: Removed the color property to prevent inverting the logo in dark mode.
                        errorBuilder: (context, error, stackTrace) =>
                            Icon(Icons.business, size: 80, color: Theme.of(context).colorScheme.primary),
                      ),
                      const SizedBox(height: 20),
                      Text("IOCL Attendance", style: Theme.of(context).textTheme.headlineLarge),
                      const SizedBox(height: 10),
                      const Text("Welcome back! Please sign in.", style: TextStyle(fontSize: 16)),
                      const SizedBox(height: 50),
                      const Text("8-Digit Employee Code"),
                      const SizedBox(height: 8),
                      Pinput(
                        controller: _employeeCodeController,
                        length: 8,
                        defaultPinTheme: _isBlinkingRed ? redBlinkTheme : (_isBlinkingGreen ? greenBlinkTheme : defaultPinTheme),
                        focusedPinTheme: defaultPinTheme.copyWith(decoration: defaultPinTheme.decoration!.copyWith(border: Border.all(color: Theme.of(context).primaryColor, width: 2))),
                        submittedPinTheme: greenBlinkTheme,
                      ),
                      const SizedBox(height: 20),
                      TextField(
                        controller: _passwordController,
                        focusNode: _passwordFocusNode,
                        obscureText: !_isPasswordVisible,
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.lock_outline, color: Theme.of(context).colorScheme.primary),
                          hintText: "Password",
                          suffixIcon: IconButton(
                            icon: Icon(_isPasswordVisible ? Icons.visibility : Icons.visibility_off, color: Theme.of(context).colorScheme.primary),
                            onPressed: () => setState(() => _isPasswordVisible = !_isPasswordVisible),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () { /* TODO: Implement Forgot Password */ },
                          child: Text("Forgot Password?", style: TextStyle(color: Theme.of(context).colorScheme.primary)),
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(width: double.infinity, child: _buildAnimatedLoginButton()),
                      _buildErrorMessage(),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text("Don't have an account?"),
                          TextButton(
                            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const SignupPage())),
                            child: const Text("Sign Up", style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFD9531E))),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 40,
            right: 20,
            child: IconButton(
              icon: Icon(isDarkMode ? Icons.wb_sunny_outlined : Icons.nightlight_round_outlined),
              tooltip: 'Toggle Theme',
              onPressed: () {
                themeProvider.toggleTheme(!isDarkMode);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedLoginButton() {
    return LayoutBuilder(builder: (context, constraints) {
      return GestureDetector(
        onTap: _signIn,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: double.infinity,
              height: 50,
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: _buttonState == ButtonState.loading
                    ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2)
                    : const Text(
                  "Login",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            AnimatedBuilder(
              animation: _animationController,
              builder: (context, child) {
                if (_buttonState != ButtonState.success && _buttonState != ButtonState.error) {
                  return const SizedBox.shrink();
                }

                return ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Container(
                      width: constraints.maxWidth * _animationController.value,
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: _buttonState == ButtonState.success
                              ? [Colors.green.shade400, Colors.green.shade700]
                              : [Colors.red.shade400, Colors.red.shade700],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                      ),
                      child: Center(
                        child: AnimatedOpacity(
                          opacity: _animationController.value > 0.5 ? 1.0 : 0.0,
                          duration: const Duration(milliseconds: 200),
                          child: Text(
                            _buttonState == ButtonState.success ? "Success!" : "Failed!",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      );
    });
  }

  Widget _buildErrorMessage() {
    IconData icon;
    switch(_errorType) {
      case ErrorType.validation:
        icon = Icons.warning_amber_rounded;
        break;
      case ErrorType.auth:
        icon = Icons.gpp_bad_outlined;
        break;
      default:
        icon = Icons.error_outline;
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      transitionBuilder: (Widget child, Animation<double> animation) {
        return FadeTransition(
          opacity: animation,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0.0, -0.5),
              end: Offset.zero,
            ).animate(animation),
            child: child,
          ),
        );
      },
      child: _errorMessage != null
          ? Padding(
        key: const ValueKey('error'),
        padding: const EdgeInsets.only(top: 16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.red.shade700, size: 20),
            const SizedBox(width: 8),
            Text(
              _errorMessage!,
              style: TextStyle(
                color: Colors.red.shade700,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ],
        ),
      )
          : const SizedBox(key: ValueKey('empty'), height: 36),
    );
  }
}
