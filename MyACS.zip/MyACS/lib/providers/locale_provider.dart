// lib/providers/locale_provider.dart

import 'package:flutter/material.dart';

class LocaleProvider with ChangeNotifier {
  Locale? _locale;

  Locale? get locale => _locale;

  void setLocale(Locale locale) {
    // Check if the new locale is supported before setting it.
    if (!L10n.all.contains(locale)) return;

    _locale = locale;
    notifyListeners();
  }
}

// Helper class to make accessing supported locales easier
class L10n {
  static final all = [
    const Locale('en'),
    const Locale('hi'),
  ];
}