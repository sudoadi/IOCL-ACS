import 'package:flutter/material.dart';

class ProfileHeader extends StatelessWidget {
  final Map<String, dynamic>? profile;

  const ProfileHeader({
    super.key,
    required this.profile,
  });

  @override
  Widget build(BuildContext context) {
    final name = profile?['EMPNAME'] ?? 'Employee';
    // Updated to use PHOTO_URL to match the new database schema
    final avatarUrl = profile?['PHOTO_URL'];
    // Access the employee number
    final empNo = profile?['EMPNO'];

    return Row(
      children: [
        CircleAvatar(
          radius: 35,
          backgroundColor: Theme.of(context).cardColor,
          backgroundImage: (avatarUrl != null && avatarUrl.isNotEmpty) ? NetworkImage(avatarUrl) : null,
          child: (avatarUrl == null || avatarUrl.isEmpty) ? const Icon(Icons.person, size: 35, color: Colors.grey) : null,
        ),
        const SizedBox(width: 15),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Welcome back,"),
              const SizedBox(height: 4),
              Text(
                name,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
              // Display EMPNO if it exists
              if (empNo != null && empNo.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(
                  'EMP NO: $empNo',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).textTheme.bodySmall?.color?.withOpacity(0.7)
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}