import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:month_picker_dialog/month_picker_dialog.dart';
import 'package:myacs/main.dart';
import 'package:myacs/pages/auth/login_page.dart';
import 'package:myacs/providers/attendance_provider.dart';
import 'package:myacs/widgets/profile_header.dart';
import 'package:myacs/widgets/stats_grid.dart';
import 'package:myacs/widgets/recent_activity_list.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// --- MODIFIED: Converted to StatefulWidget to manage server time ---
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DateTime? _serverTime;

  @override
  void initState() {
    super.initState();
    _fetchServerTime();
  }

  // --- ADDED: Method to fetch current time from the server ---
  /// Fetches the current time to be used for expiring old regularizations.
  /// In a real app, this should call a trusted time source (e.g., a Supabase edge function).
  Future<void> _fetchServerTime() async {
    // For demonstration, we use the device's local time.
    // To use a Supabase RPC function named 'get_current_timestamp', you would do:
    // final response = await supabase.rpc('get_current_timestamp');
    // final serverTimeStr = response as String;
    if (mounted) {
      setState(() {
        _serverTime = DateTime.now(); // Replace with `DateTime.parse(serverTimeStr)`
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final attendanceProvider = Provider.of<AttendanceProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Dashboard"),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await supabase.auth.signOut();
              if (context.mounted) {
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => const LoginPage()), (route) => false);
              }
            },
          ),
        ],
      ),
      body: attendanceProvider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
        onRefresh: () async {
          // Also refresh server time on pull-to-refresh
          await _fetchServerTime();
          await attendanceProvider.fetchDataForMonth(attendanceProvider.selectedDate);
        },
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
          children: [
            ProfileHeader(profile: attendanceProvider.profile),
            const SizedBox(height: 30),
            _buildMonthSelector(context, attendanceProvider),
            const SizedBox(height: 20),
            StatsGrid(
              presentDays: attendanceProvider.presentDays,
              absentDays: attendanceProvider.absentDays,
              totalWorkingDays: attendanceProvider.totalWorkingDays,
              avgInTime: attendanceProvider.avgInTime,
              avgOutTime: attendanceProvider.avgOutTime,
              pendingRegularizations: attendanceProvider.pendingRegularizations,
              approvedRegularizations: attendanceProvider.approvedRegularizations,
              onPresentLongPress: () => _showStatListDialog(context, "Present", attendanceProvider.attendanceRecords.where((r) => r['STATUS'] == 'PRESENT').toList(), Colors.green),
              onAbsentLongPress: () => _showStatListDialog(context, "Absent", attendanceProvider.attendanceRecords.where((r) => r['STATUS'] == 'ABSENT').toList(), Colors.red),
              onRegularizationLongPress: () => _showRegularizationDialog(context, attendanceProvider),
            ),
            const SizedBox(height: 30),
            _buildSectionTitle(context, "Recent Activity"),
            const SizedBox(height: 10),
            RecentActivityList(
              attendanceRecords: attendanceProvider.attendanceRecords,
              // --- MODIFIED: Pass server time to the list and dialog ---
              serverTime: _serverTime,
              onRecordLongPress: (ctx, record) => _showAttendanceDetailsDialog(ctx, record, _serverTime),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectMonth(BuildContext context, AttendanceProvider provider) async {
    final DateTime? picked = await showMonthPicker(
      context: context,
      initialDate: provider.selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      provider.changeMonth(picked);
    }
  }

  Widget _buildMonthSelector(BuildContext context, AttendanceProvider provider) {
    final selectedDate = provider.selectedDate;
    bool isCurrentMonth = selectedDate.year == DateTime.now().year && selectedDate.month == DateTime.now().month;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text("In this Month", style: Theme.of(context).textTheme.titleLarge),
        Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10)],
          ),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.chevron_left),
                onPressed: () {
                  final newDate = DateTime(selectedDate.year, selectedDate.month - 1, 1);
                  provider.changeMonth(newDate);
                },
              ),
              GestureDetector(
                onTap: () => _selectMonth(context, provider),
                child: Text(
                  DateFormat('MMMM yyyy').format(selectedDate),
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.chevron_right),
                onPressed: isCurrentMonth
                    ? null
                    : () {
                  final newDate = DateTime(selectedDate.year, selectedDate.month + 1, 1);
                  provider.changeMonth(newDate);
                },
              ),
            ],
          ),
        )
      ],
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold));
  }
}

// --- DIALOG LOGIC ---

const List<Map<String, String>> _detailDefinitions = [
  {'dbKey': 'STATUS', 'title': 'Status'},
  {'dbKey': 'DAYINFO', 'title': 'Day Info'},
  {'dbKey': 'INSWIPE', 'title': 'In Swipe'},
  {'dbKey': 'OUTSWIPE', 'title': 'Out Swipe'},
  {'dbKey': 'MANHOURS', 'title': 'Man Hours'},
  {'dbKey': 'DIVIDER', 'title': ''}, // Divider definition
  {'dbKey': 'WORK_SCHEDULE', 'title': 'Work Schedule'},
  {'dbKey': 'REGION', 'title': 'Region'},
  {'dbKey': 'LOCATION', 'title': 'Location'},
  {'dbKey': 'DIVIDER', 'title': ''},
  {'dbKey': 'APPROVER', 'title': 'Approver'},
  {'dbKey': 'ACS_STATUS', 'title': 'ACS Status'},
  {'dbKey': 'LOSS_OF_PAY', 'title': 'Loss of Pay'},
  {'dbKey': 'APPROVAL_STATUS', 'title': 'Approval Status'},
  {'dbKey': 'DIVIDER', 'title': ''},
  {'dbKey': 'REASON', 'title': 'Reason'},
  {'dbKey': 'OTHER_REASON', 'title': 'Other Reason'},
  {'dbKey': 'REASON_ENTERED', 'title': 'Reason Entered'},
];

String _formatValue(String key, dynamic value) {
  if (value == null) return 'N/A';
  String stringValue = value.toString();
  switch (key) {
    case 'INSWIPE':
    case 'OUTSWIPE':
      try {
        return DateFormat('h:mm:ss a').format(DateTime.parse(stringValue));
      } catch (e) {
        return stringValue;
      }
    default:
      return stringValue;
  }
}

Future<String?> _getApproverName(String approverEmpNo) async {
  try {
    final response = await supabase.from('profiles').select('EMPNAME').eq('EMPNO', approverEmpNo).single();
    return response['EMPNAME'] as String?;
  } catch (e) {
    return 'Not Found';
  }
}

// --- MODIFIED: Dialog now accepts serverTime to check for expiration ---
void _showAttendanceDetailsDialog(BuildContext context, Map<String, dynamic> record, DateTime? serverTime) {
  Widget buildDetailRow(String title, String displayValue) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$title: ', style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).textTheme.bodySmall?.color)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(displayValue, style: TextStyle(color: displayValue == 'N/A' ? Colors.red : Theme.of(context).textTheme.bodyLarge?.color, fontWeight: displayValue == 'N/A' ? FontWeight.bold : FontWeight.normal)),
          ),
        ],
      ),
    );
  }

  showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
    transitionDuration: const Duration(milliseconds: 300),
    pageBuilder: (context, anim1, anim2) {
      final date = DateTime.parse(record['SHIFTDATE']);

      final List<Widget> detailWidgets = [];
      for (var def in _detailDefinitions) {
        final dbKey = def['dbKey']!;
        final title = def['title']!;
        final rawValue = record[dbKey];

        if (dbKey == 'DIVIDER') {
          detailWidgets.add(const Divider());
          continue;
        }

        if (rawValue != null && rawValue.toString().trim().isNotEmpty) {
          final formattedValue = _formatValue(dbKey, rawValue);
          detailWidgets.add(buildDetailRow(title, formattedValue));

          if (dbKey == 'APPROVER') {
            detailWidgets.add(
              FutureBuilder<String?>(
                future: _getApproverName(rawValue.toString()),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Padding(padding: EdgeInsets.symmetric(vertical: 8.0), child: Center(child: SizedBox(height: 15, width: 15, child: CircularProgressIndicator(strokeWidth: 2))));
                  }
                  if (snapshot.hasData && snapshot.data != null) {
                    return buildDetailRow('Approver Name', snapshot.data!);
                  }
                  return const SizedBox.shrink();
                },
              ),
            );
          }
        }
      }

      return AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Details for ${DateFormat.yMMMMd().format(date)}'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: detailWidgets,
          ),
        ),
        actions: [
          _buildDialogActions(context, record, serverTime),
        ],
      );
    },
  );
}

// --- MODIFIED: Action button logic now checks if the regularization is expired ---
Widget _buildDialogActions(BuildContext context, Map<String, dynamic> record, DateTime? serverTime) {
  final inSwipeTime = record['INSWIPE'] != null ? DateTime.parse(record['INSWIPE']) : null;
  final isLate = inSwipeTime != null && (inSwipeTime.hour > 10 || (inSwipeTime.hour == 10 && inSwipeTime.minute > 15));
  final approvalStatus = record['APPROVAL_STATUS']?.toString();
  final reason = record['REASON']?.toString();

  // --- ADDED: Expiration check logic ---
  bool isExpired = false;
  if (serverTime != null && reason == null && isLate) {
    final recordDate = DateTime.parse(record['SHIFTDATE']);
    if (serverTime.difference(recordDate).inDays > 30) {
      isExpired = true;
    }
  }

  Widget actionButton;

  if (isLate) {
    if (approvalStatus == '1') {
      actionButton = ElevatedButton.icon(onPressed: null, icon: const Icon(Icons.check_circle, color: Colors.white), label: const Text('Approved'), style: ElevatedButton.styleFrom(backgroundColor: Colors.green, disabledForegroundColor: Colors.white.withAlpha(220), disabledBackgroundColor: Colors.green));
    } else if (approvalStatus == '0') {
      actionButton = ElevatedButton.icon(onPressed: null, icon: const Icon(Icons.cancel, color: Colors.white), label: const Text('Not Approved'), style: ElevatedButton.styleFrom(backgroundColor: Colors.red, disabledForegroundColor: Colors.white.withAlpha(220), disabledBackgroundColor: Colors.red));
    } else if (reason != null && reason.trim().isNotEmpty) {
      actionButton = const ElevatedButton(onPressed: null, child: Text('Pending'));
    } else if (isExpired) {
      // --- ADDED: Show a disabled "Expired" button ---
      actionButton = ElevatedButton.icon(onPressed: null, icon: const Icon(Icons.timer_off, color: Colors.white), label: const Text('Expired'), style: ElevatedButton.styleFrom(backgroundColor: Colors.grey, disabledForegroundColor: Colors.white.withAlpha(220), disabledBackgroundColor: Colors.grey));
    } else {
      actionButton = ElevatedButton(
        onPressed: () {
          Navigator.of(context).pop();
          _showRegularizationFormDialog(context, record);
        },
        child: const Text('Regularize'),
        style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
      );
    }
  } else {
    actionButton = const SizedBox.shrink();
  }

  return Row(
    mainAxisAlignment: MainAxisAlignment.end,
    children: [
      actionButton,
      TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Close')),
    ],
  );
}


void _showRegularizationFormDialog(BuildContext context, Map<String, dynamic> record) {
  final formKey = GlobalKey<FormState>();
  final reasonController = TextEditingController();
  final attendanceProvider = Provider.of<AttendanceProvider>(context, listen: false);

  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: const Text('Regularize Attendance'),
        content: Form(
          key: formKey,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('Please provide a reason for your late arrival on ${DateFormat.yMMMMd().format(DateTime.parse(record['SHIFTDATE']))}.'),
            const SizedBox(height: 20),
            TextFormField(controller: reasonController, decoration: const InputDecoration(labelText: 'Reason', border: OutlineInputBorder()), validator: (value) => (value == null || value.trim().isEmpty) ? 'Please enter a reason.' : null, maxLines: 3),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (formKey.currentState!.validate()) {
                try {
                  final attendanceId = record['id'];
                  final reason = reasonController.text.trim();
                  await supabase.from('attendance').update({'REASON': reason}).eq('id', attendanceId);
                  if (!context.mounted) return;
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Regularization request submitted.'), backgroundColor: Colors.green));
                  attendanceProvider.fetchDataForMonth(attendanceProvider.selectedDate);
                } catch (e) {
                  if (!context.mounted) return;
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error submitting request: $e'), backgroundColor: Colors.red));
                }
              }
            },
            child: const Text('Submit'),
          ),
        ],
      );
    },
  );
}

void _showStatListDialog(BuildContext context, String title, List<Map<String, dynamic>> records, Color color) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(children: [Icon(Icons.list_alt, color: color), const SizedBox(width: 10), Text('$title Days')]),
      content: SizedBox(
        width: double.maxFinite,
        child: records.isEmpty
            ? const Center(child: Text('No records found.'))
            : ListView.builder(shrinkWrap: true, itemCount: records.length, itemBuilder: (context, index) {
          final record = records[index];
          final date = DateTime.parse(record['SHIFTDATE']);
          return ListTile(title: Text(DateFormat.yMMMMd().format(date)), subtitle: Text(record['DAYINFO'] ?? ''));
        }),
      ),
      actions: [TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('OK'))],
    ),
  );
}

void _showRegularizationDialog(BuildContext context, AttendanceProvider provider) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Regularization Status'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Pending: ${provider.pendingRegularizations}'),
          Text('Approved: ${provider.approvedRegularizations}'),
        ],
      ),
      actions: [TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('OK'))],
    ),
  );
}