import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

// Data model for a single chat message
class ChatMessage {
  String? text; // Changed from final to allow updates
  final XFile? imageFile;
  final String? imageUrl;
  final bool isUser;

  ChatMessage({this.text, this.imageFile, this.imageUrl, required this.isUser});

  Map<String, dynamic> toJson() => {
    'text': text,
    'imageUrl': imageUrl,
    'isUser': isUser,
  };

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
    text: json['text'],
    imageUrl: json['imageUrl'],
    isUser: json['isUser'],
  );
}

class ChatbotPage extends StatefulWidget {
  final Map<String, dynamic>? userProfile;
  final bool isFullScreen;

  const ChatbotPage({super.key, this.userProfile, this.isFullScreen = false});

  static Future<void> clearChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('chat_history');
  }

  @override
  State<ChatbotPage> createState() => _ChatbotPageState();
}

class _ChatbotPageState extends State<ChatbotPage> {
  // TODO: IMPORTANT - Add these packages to your pubspec.yaml file:
  // dependencies:
  //   pdf: ^3.10.8
  //   printing: ^5.12.0
  //   share_plus: ^9.0.0
  //   image_picker: ^1.1.2

  // IMPORTANT: Replace with your actual Mistral AI API key.
  final String _apiKey = "DssdqG2KM5nUCbC5hB2FTkKBjgT9Z6sf";

  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;
  XFile? _selectedImage;
  final http.Client _client = http.Client(); // Create a client for streaming

  @override
  void initState() {
    super.initState();
    _loadChatHistory();
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    _client.close(); // Close the client when the widget is disposed
    super.dispose();
  }

  Future<void> _loadChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final chatHistoryJson = prefs.getStringList('chat_history') ?? [];
    if (chatHistoryJson.isEmpty) {
      final name = widget.userProfile?['EMPNAME']?.split(' ').first ?? 'there';
      setState(() {
        _messages.add(ChatMessage(
            text:
            "Hello $name! I'm your friendly AI assistant. How can I help you with the MyACS app today?",
            isUser: false));
      });
    } else {
      setState(() {
        _messages.addAll(chatHistoryJson
            .map((json) => ChatMessage.fromJson(jsonDecode(json))));
      });
    }
  }

  Future<void> _saveChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final storableMessages = _messages.where((msg) => msg.imageFile == null);
    final chatHistoryJson =
    storableMessages.map((msg) => jsonEncode(msg.toJson())).toList();
    await prefs.setStringList('chat_history', chatHistoryJson);
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: source);
    if (image != null) {
      setState(() {
        _selectedImage = image;
      });
    }
  }

  void _showImagePickerOptions() {
    showCupertinoModalPopup(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        title: const Text('Select Image Source'),
        actions: <CupertinoActionSheetAction>[
          CupertinoActionSheetAction(
            child: const Text('Take Photo'),
            onPressed: () {
              Navigator.pop(context);
              _pickImage(ImageSource.camera);
            },
          ),
          CupertinoActionSheetAction(
            child: const Text('Choose from Library'),
            onPressed: () {
              Navigator.pop(context);
              _pickImage(ImageSource.gallery);
            },
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          isDefaultAction: true,
          onPressed: () {
            Navigator.pop(context);
          },
          child: const Text('Cancel'),
        ),
      ),
    );
  }

  Future<void> _exportAndShareResponse(String text) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Header(
                level: 0,
                child: pw.Text('AI Assistant Response', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 20)),
              ),
              pw.Paragraph(text: text),
            ],
          );
        },
      ),
    );

    await Printing.sharePdf(bytes: await pdf.save(), filename: 'ai_response.pdf');
  }

  // UPDATED: This function now builds the payload for a text-only model.
  List<Map<String, dynamic>> _buildHistoryForApi(String? text, String? imageBase64) {
    final List<Map<String, dynamic>> history = [];
    final userName = widget.userProfile?['EMPNAME'] ?? 'the user';

    history.add({
      'role': 'system',
      'content': """
          You are a friendly and helpful AI assistant for the "MyACS" mobile app, an attendance management system for IOCL employees.
          Your goal is to help users understand how to use the app's features by providing text-based answers.
          If a user asks for a table or chart, format your response using Markdown.
          You cannot generate images.

          Here is a detailed summary of the app's features:

          **1. Authentication (Login & Signup):**
          - To log in, users need their 8-digit Employee Code and a password.
          - The "Signup" page is for employees who are already in the database but haven't created an app account yet. It allows them to set a password for their profile by linking their email to it.

          **2. Main Pages (Dashboard & Navigation):**
          - **Home Page:** This is the main dashboard. It shows a summary of the current month's attendance: Present days, Absent days, Total working days, and Average In/Out times. It also shows the status of regularization requests (Pending/Approved) and a list of "Recent Activity".
          - **History Page:** This page provides a visual summary of attendance for the selected month using a pie chart, breaking down days into "Present," "Absent," and "On Leave."
          - **Profile Page:** Users can view their own detailed profile information, change their profile picture, toggle app settings like Notifications and Dark Mode, and log out.

          **3. Regularization Feature (Core Functionality):**
          - This is for fixing attendance errors, like when an employee is marked absent but was actually present, or for late arrivals/early departures.
          - **My Requests:** Users can tap this to see a list of their own attendance correction requests and check their status (Pending, Approved, or Not Approved).
          - **Approve Requests:** This is a feature for managers. Managers see a list of pending requests from their team members and can approve or decline them.
          
          **4. User & Team Management (for Managers):**
          - **Team Member Profile:** From the "Approve Requests" page, a manager can tap on a request to view the detailed profile and attendance history of that team member.
          - **Global Search:** The "Approve Requests" page also has a global search function that allows a manager to find any employee in the company, not just their direct reports, and view their public profile.

          **Your Task:**
          - Answer user questions based on this knowledge.
          - Keep your answers concise, friendly, and focused on the app's functionality.
          - If you don't know the answer, say so politely.
          - Do NOT greet the user again after your first message.
          - IMPORTANT: Your final response should only be the answer. Do not include your thought process or XML tags.
          - Say GOOD MORNING with every message
          """
    });

    // Add previous messages to the history
    for (var message in _messages) {
      if (message.text != null && message.text!.isNotEmpty) {
        history.add({
          'role': message.isUser ? 'user' : 'assistant',
          'content': message.text
        });
      }
    }

    // Build the content for the current user message
    // NOTE: Mistral Large is not a vision model. We only send the text part.
    // The image will be displayed in the UI but not sent to the API.
    if (text != null && text.isNotEmpty) {
      history.add({'role': 'user', 'content': text});
    }

    return history;
  }

  // UPDATED: This function now connects to the Mistral AI API.
  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty && _selectedImage == null) return;

    final userMessage = ChatMessage(text: text, imageFile: _selectedImage, isUser: true);

    setState(() {
      _messages.add(userMessage);
      _isLoading = true;
      _selectedImage = null; // Clear the selected image after sending
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    _controller.clear();

    String? imageBase64;
    if (userMessage.imageFile != null) {
      final imageBytes = await userMessage.imageFile!.readAsBytes();
      imageBase64 = base64Encode(imageBytes);
    }

    // Add an empty message for the bot's response to be streamed into.
    setState(() {
      _messages.add(ChatMessage(text: '', isUser: false));
    });

    try {
      final url = Uri.parse('https://api.mistral.ai/v1/chat/completions');
      final request = http.Request('POST', url);

      request.headers.addAll({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $_apiKey',
      });

      request.body = jsonEncode({
        'model': 'mistral-large-latest',
        'messages': _buildHistoryForApi(text, imageBase64),
        'stream': true,
      });

      final http.StreamedResponse response = await _client.send(request);

      if (response.statusCode == 200) {
        response.stream
            .transform(utf8.decoder)
            .transform(const LineSplitter())
            .listen(
              (line) {
            if (line.startsWith('data: ')) {
              final jsonString = line.substring(6);
              if (jsonString == '[DONE]') {
                setState(() {
                  _isLoading = false;
                });
                _saveChatHistory();
                return;
              }
              try {
                final jsonResponse = jsonDecode(jsonString);
                final content = jsonResponse['choices'][0]['delta']['content'];
                if (content != null) {
                  setState(() {
                    _messages.last.text = (_messages.last.text ?? '') + content;
                    _scrollToBottom();
                  });
                }
              } catch (e) {
                // Ignore parsing errors for incomplete JSON
              }
            }
          },
          onDone: () {
            if (mounted) {
              setState(() {
                _isLoading = false;
              });
              _saveChatHistory();
            }
          },
          onError: (error) {
            if (mounted) {
              _showError('Failed to process stream: $error');
            }
          },
        );
      } else {
        final responseBody = await response.stream.bytesToString();
        _showError('API Error: ${response.reasonPhrase}\n$responseBody');
      }
    } catch (e) {
      _showError('An error occurred: $e');
    }
  }

  void _showError(String message) {
    if (mounted) {
      // Remove the empty message placeholder if an error occurs
      if (_messages.last.text != null && _messages.last.text!.isEmpty && !_messages.last.isUser) {
        _messages.removeLast();
      }
      setState(() {
        _messages.add(ChatMessage(
            text: "Sorry, I couldn't connect. Please check your API key and network. Error: $message",
            isUser: false));
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final backgroundColor = isDarkMode
        ? Colors.black.withOpacity(0.85)
        : Colors.white.withOpacity(0.85);
    final navBarTextColor = isDarkMode ? Colors.white : Colors.black;
    final navBarIconColor = isDarkMode ? Colors.white : Colors.black;

    return CupertinoPageScaffold(
      backgroundColor: widget.isFullScreen ? (isDarkMode ? Colors.black : Colors.white) : backgroundColor,
      navigationBar: CupertinoNavigationBar(
        backgroundColor: widget.isFullScreen ? (isDarkMode ? CupertinoColors.darkBackgroundGray : CupertinoColors.white) : Colors.transparent,
        border: null,
        middle: Text('AI Assistant', style: TextStyle(color: navBarTextColor)),
        trailing: widget.isFullScreen
            ? null
            : Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            CupertinoButton(
              padding: const EdgeInsets.only(left: 8.0),
              child: Icon(CupertinoIcons.fullscreen, color: navBarIconColor),
              onPressed: () => Navigator.of(context).pop(true),
            ),
            CupertinoButton(
              padding: const EdgeInsets.only(left: 8.0),
              child: Icon(CupertinoIcons.clear_thick, color: navBarIconColor),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.all(16.0),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final message = _messages[index];
                  return _buildMessageBubble(message, isDarkMode);
                },
              ),
            ),
            if (_isLoading)
              const Padding(
                padding: EdgeInsets.all(8.0),
                child: CupertinoActivityIndicator(),
              ),
            _buildUserInput(isDarkMode),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message, bool isDarkMode) {
    // Hide empty bot messages before content starts streaming in
    if (message.text != null && message.text!.isEmpty && !message.isUser && message.imageFile == null && message.imageUrl == null) {
      return const SizedBox.shrink();
    }

    final isUser = message.isUser;
    final botBubbleColor = isDarkMode
        ? Colors.white.withOpacity(0.15)
        : CupertinoColors.systemGrey5;
    final userTextColor = isDarkMode ? Colors.white : Colors.white;
    final botTextColor = isDarkMode ? Colors.white : Colors.black;

    // The user's message can contain both an image and text.
    final hasText = message.text != null && message.text!.isNotEmpty;
    final hasImage = message.imageFile != null || message.imageUrl != null;

    Widget imageWidget = const SizedBox.shrink();
    if(message.imageFile != null){
      imageWidget = Image.file(File(message.imageFile!.path), fit: BoxFit.contain);
    } else if (message.imageUrl != null){
      imageWidget = Image.memory(base64Decode(message.imageUrl!.split(',')[1]));
    }

    return Row(
      mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
      children: [
        Flexible(
          child: Container(
              margin: const EdgeInsets.symmetric(vertical: 4.0),
              padding: const EdgeInsets.all(12.0),
              decoration: BoxDecoration(
                color: isUser ? CupertinoColors.activeBlue : botBubbleColor,
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (hasImage)
                    Padding(
                      padding: EdgeInsets.only(bottom: hasText ? 8.0 : 0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: imageWidget,
                      ),
                    ),
                  if (hasText)
                    Text(message.text!, style: TextStyle(color: isUser ? userTextColor : botTextColor)),
                ],
              )
          ),
        ),
        if (!isUser && hasText)
          IconButton(
            icon: Icon(CupertinoIcons.share, color: Colors.grey.shade600, size: 20),
            onPressed: () => _exportAndShareResponse(message.text!),
          ),
      ],
    );
  }

  Widget _buildUserInput(bool isDarkMode) {
    final inputFieldColor = isDarkMode
        ? Colors.white.withOpacity(0.1)
        : CupertinoColors.systemGrey6;
    final placeholderColor = isDarkMode
        ? Colors.white.withOpacity(0.6)
        : Colors.black.withOpacity(0.6);
    final inputTextColor = isDarkMode ? Colors.white : Colors.black;

    return Container(
      padding: const EdgeInsets.all(12.0),
      decoration: BoxDecoration(
        color: widget.isFullScreen ? (isDarkMode ? CupertinoColors.darkBackgroundGray : CupertinoColors.white) : Colors.transparent,
        border: null,
      ),
      child: Column(
        children: [
          if (_selectedImage != null)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: inputFieldColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.file(
                      File(_selectedImage!.path),
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Expanded(child: Text("Image selected (will not be processed by AI)", style: TextStyle(color: Colors.grey))),
                  IconButton(
                    icon: const Icon(CupertinoIcons.clear_circled_solid, color: Colors.grey),
                    onPressed: () => setState(() => _selectedImage = null),
                  )
                ],
              ),
            ),
          Row(
            children: [
              CupertinoButton(
                padding: const EdgeInsets.only(right: 8),
                onPressed: _showImagePickerOptions,
                child: const Icon(CupertinoIcons.camera, size: 28),
              ),
              Expanded(
                child: CupertinoTextField(
                  controller: _controller,
                  placeholder: 'Ask a question...',
                  placeholderStyle: TextStyle(color: placeholderColor),
                  style: TextStyle(color: inputTextColor),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: inputFieldColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  onSubmitted: (_) => _sendMessage(),
                ),
              ),
              const SizedBox(width: 8.0),
              CupertinoButton(
                padding: EdgeInsets.zero,
                onPressed: _sendMessage,
                child: const Icon(CupertinoIcons.arrow_up_circle_fill, size: 32),
              ),
            ],
          ),
        ],
      ),
    );
  }
}