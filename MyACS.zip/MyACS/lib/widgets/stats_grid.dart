import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class StatsGrid extends StatelessWidget {
  final int presentDays;
  final int absentDays;
  final int pendingRegularizations;
  final int approvedRegularizations;
  final int totalWorkingDays;
  final String avgInTime;
  final String avgOutTime;
  final VoidCallback onPresentLongPress;
  final VoidCallback onAbsentLongPress;
  final VoidCallback onRegularizationLongPress;

  const StatsGrid({
    super.key,
    required this.presentDays,
    required this.absentDays,
    required this.pendingRegularizations,
    required this.approvedRegularizations,
    required this.totalWorkingDays,
    required this.avgInTime,
    required this.avgOutTime,
    required this.onPresentLongPress,
    required this.onAbsentLongPress,
    required this.onRegularizationLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      crossAxisSpacing: 15,
      mainAxisSpacing: 15,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.2,
      children: [
        _buildStatCard(context, "Present", presentDays.toString(), Icons.check_circle_outline, Colors.green, onPresentLongPress),
        _buildStatCard(context, "Absent", absentDays.toString(), Icons.cancel_outlined, Colors.red, onAbsentLongPress),
        _buildStatCard(context, "Regularizations", "", Icons.rule_folder_outlined, Colors.teal, onRegularizationLongPress, isComplex: true),
        _buildStatCard(context, "Working Days", totalWorkingDays.toString(), Icons.work_outline, Colors.blueGrey, () {}),
        _buildStatCard(context, "Avg. In-Time", avgInTime, Icons.access_time_outlined, Colors.blue, () {}),
        _buildStatCard(context, "Avg. Out-Time", avgOutTime, Icons.timer_off_outlined, Colors.purple, () {}),
      ],
    );
  }

  Widget _buildStatCard(BuildContext context, String title, String value, IconData icon, Color color, VoidCallback onLongPress, {bool isComplex = false}) {
    return GestureDetector(
      onLongPress: () {
        HapticFeedback.mediumImpact();
        onLongPress();
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(15), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), spreadRadius: 2, blurRadius: 10, offset: const Offset(0, 5))]),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 20),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    title,
                    style: Theme.of(context).textTheme.bodySmall,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const Spacer(),
            if (isComplex)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Pending: $pendingRegularizations", style: Theme.of(context).textTheme.bodyMedium),
                  Text("Approved: $approvedRegularizations", style: Theme.of(context).textTheme.bodyMedium),
                ],
              )
            else
              Center(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    value,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            const Spacer(),
          ],
        ),
      ),
    );
  }
}