import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:myacs/main.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AttendanceProvider with ChangeNotifier {
  Map<String, dynamic>? _profile;
  List<Map<String, dynamic>> _attendanceRecords = [];
  bool _isLoading = true;
  DateTime _selectedDate = DateTime.now();

  // Stats
  int _presentDays = 0;
  int _absentDays = 0;
  int _weeklyOffDays = 0;
  int _totalWorkingDays = 0;
  String _avgInTime = "N/A";
  String _avgOutTime = "N/A";
  int _pendingRegularizations = 0;
  int _approvedRegularizations = 0;
  int _leaveDays = 0;


  // Getters
  Map<String, dynamic>? get profile => _profile;
  List<Map<String, dynamic>> get attendanceRecords => _attendanceRecords;
  bool get isLoading => _isLoading;
  DateTime get selectedDate => _selectedDate;
  int get presentDays => _presentDays;
  int get absentDays => _absentDays;
  int get weeklyOffDays => _weeklyOffDays;
  int get totalWorkingDays => _totalWorkingDays;
  String get avgInTime => _avgInTime;
  String get avgOutTime => _avgOutTime;
  int get pendingRegularizations => _pendingRegularizations;
  int get approvedRegularizations => _approvedRegularizations;
  int get leaveDays => _leaveDays;

  AttendanceProvider() {
    fetchDataForMonth(_selectedDate);
  }

  Future<void> fetchDataForMonth(DateTime date) async {
    _isLoading = true;
    _selectedDate = date;
    notifyListeners();

    try {
      if (_profile == null) {
        final userId = supabase.auth.currentUser!.id;
        _profile = await supabase.from('profiles').select().eq('ID', userId).single();
      }

      final empNo = _profile?['EMPNO'];
      if (empNo == null) throw "Could not find employee number.";

      final firstDayOfMonth = DateTime(date.year, date.month, 1);
      final lastDayOfMonth = DateTime(date.year, date.month + 1, 0);

      final response = await supabase
          .from('attendance')
          .select()
          .eq('EMPNO', empNo)
          .gte('SHIFTDATE', firstDayOfMonth.toIso8601String())
          .lte('SHIFTDATE', lastDayOfMonth.toIso8601String())
          .order('SHIFTDATE', ascending: false);

      _attendanceRecords = List<Map<String, dynamic>>.from(response);
      _calculateMonthlyStats();

    } catch (e) {
      // In a real app, you'd want to handle this error more gracefully
      print("Error fetching data: ${e.toString()}");
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void changeMonth(DateTime newDate){
    if (newDate.month != _selectedDate.month || newDate.year != _selectedDate.year) {
      fetchDataForMonth(newDate);
    }
  }


  void _calculateMonthlyStats() {
    int present = 0;
    int absent = 0;
    int weeklyOff = 0;
    int leave = 0;

    for (final record in _attendanceRecords) {
      final status = record['STATUS']?.toString().toUpperCase() ?? '';
      final dayInfo = record['DAYINFO']?.toString().toUpperCase() ?? '';

      if (dayInfo == 'SATURDAY' || dayInfo == 'SUNDAY') {
        weeklyOff++;
      } else {
        if (status == 'PRESENT') {
          present++;
        } else if (status == 'ABSENT') {
          absent++;
        } else if (status == 'LEAVE') {
          leave++;
        }
      }
    }

    _presentDays = present;
    _absentDays = absent;
    _weeklyOffDays = weeklyOff;
    _leaveDays = leave;
    _totalWorkingDays = _presentDays + _absentDays;

    final checkInTimes = _attendanceRecords
        .where((rec) => rec['INSWIPE'] != null && rec['STATUS'] == 'PRESENT')
        .map((rec) => DateTime.parse(rec['INSWIPE']))
        .toList();

    if (checkInTimes.isNotEmpty) {
      double totalSeconds = checkInTimes.fold(0, (p, e) => p + (e.hour * 3600 + e.minute * 60 + e.second));
      _avgInTime = DateFormat('h:mm a').format(DateTime(2000).add(Duration(seconds: (totalSeconds / checkInTimes.length).round())));
    } else {
      _avgInTime = "N/A";
    }

    final checkOutTimes = _attendanceRecords
        .where((rec) => rec['OUTSWIPE'] != null && rec['STATUS'] == 'PRESENT')
        .map((rec) => DateTime.parse(rec['OUTSWIPE']))
        .toList();

    if (checkOutTimes.isNotEmpty) {
      double totalSeconds = checkOutTimes.fold(0, (p, e) => p + (e.hour * 3600 + e.minute * 60 + e.second));
      _avgOutTime = DateFormat('h:mm a').format(DateTime(2000).add(Duration(seconds: (totalSeconds / checkOutTimes.length).round())));
    } else {
      _avgOutTime = "N/A";
    }

    // Note: Regularization stats are currently hardcoded. You would fetch these as well.
    _pendingRegularizations = 0;
    _approvedRegularizations = 0;
  }
}
