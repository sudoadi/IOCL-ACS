package com.adikr.ioclacs.myacs;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
