import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myacs/pages/auth/splash_page.dart';
import 'package:myacs/providers/attendance_provider.dart'; // <-- FIX: Added this import
import 'package:myacs/theme_provider.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://project.supabase.co',
    anonKey: 'SUPABASE ANON KEY',
  );

  runApp(
    // Using MultiProvider to provide both ThemeProvider and AttendanceProvider
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => AttendanceProvider()),
      ],
      child: const IOCLAttendanceApp(),
    ),
  );
}

final supabase = Supabase.instance.client;

class IOCLAttendanceApp extends StatelessWidget {
  const IOCLAttendanceApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    // --- Base Text Themes for consistency ---
    final baseLightTextTheme = ThemeData.light().textTheme;
    final baseDarkTextTheme = ThemeData.dark().textTheme;

    return MaterialApp(
      title: 'IOCL Attendance',
      themeMode: themeProvider.themeMode,

      // --- Light Theme Definition ---
      theme: ThemeData(
        brightness: Brightness.light,
        primaryColor: const Color(0xFF003366),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF003366), brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF0F4F8),
        textTheme: GoogleFonts.robotoTextTheme(baseLightTextTheme).copyWith(
          headlineLarge: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF003366)),
          titleLarge: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF003366)),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: IconThemeData(color: Color(0xFF003366)),
          titleTextStyle: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF003366), fontSize: 20),
        ),
        cardColor: Colors.white,
      ),

      // --- Dark Theme Definition ---
      darkTheme: ThemeData(
          brightness: Brightness.dark,
          primaryColor: Colors.blue.shade300,
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue.shade300, brightness: Brightness.dark),
          scaffoldBackgroundColor: const Color(0xFF121212),
          cardColor: Colors.grey[850],
          textTheme: GoogleFonts.robotoTextTheme(baseDarkTextTheme.apply(
            bodyColor: Colors.white70,
            displayColor: Colors.white,
          )),
          appBarTheme: AppBarTheme(
            backgroundColor: Colors.grey[900],
            elevation: 0,
            iconTheme: const IconThemeData(color: Colors.white),
            titleTextStyle: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 20),
          ),
          dialogTheme: DialogTheme(
            backgroundColor: Colors.grey[850],
            titleTextStyle: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
            contentTextStyle: TextStyle(color: Colors.grey[300]),
          )
      ),

      debugShowCheckedModeBanner: false,
      home: const SplashPage(),
    );
  }
}
