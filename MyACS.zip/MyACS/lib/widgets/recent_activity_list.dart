import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

class RecentActivityList extends StatelessWidget {
  final List<Map<String, dynamic>> attendanceRecords;
  final DateTime? serverTime; // Accept the server time
  final Function(BuildContext, Map<String, dynamic>) onRecordLongPress;

  const RecentActivityList({
    super.key,
    required this.attendanceRecords,
    required this.onRecordLongPress,
    this.serverTime,
  });

  @override
  Widget build(BuildContext context) {
    if (attendanceRecords.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32.0),
          child: Text("No activity found for this month."),
        ),
      );
    }
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: attendanceRecords.length,
      itemBuilder: (context, index) {
        final record = attendanceRecords[index];
        final date = DateTime.parse(record['SHIFTDATE']);
        final checkIn = record['INSWIPE'] != null ? DateFormat('h:mm a').format(DateTime.parse(record['INSWIPE'])) : 'N/A';
        final checkOut = record['OUTSWIPE'] != null ? DateFormat('h:mm a').format(DateTime.parse(record['OUTSWIPE'])) : 'N/A';
        final dayInfo = record['DAYINFO']?.toString().toUpperCase() ?? '';

        String status = record['STATUS'] ?? 'ABSENT';
        if (dayInfo == 'SATURDAY' || dayInfo == 'SUNDAY') {
          status = 'WEEKLY OFF';
        }

        final inSwipeTime = record['INSWIPE'] != null ? DateTime.parse(record['INSWIPE']) : null;
        final isLate = inSwipeTime != null && (inSwipeTime.hour > 10 || (inSwipeTime.hour == 10 && inSwipeTime.minute > 15));
        final dayInitial = DateFormat('E').format(date).substring(0, 1);

        // New logic to check for expired regularization
        final reason = record['REASON']?.toString();
        bool isExpired = false;
        if (serverTime != null && reason == null && isLate) {
          if (serverTime!.difference(date).inDays > 30) {
            isExpired = true;
          }
        }

        Color statusColor;
        IconData statusIcon;
        switch (status) {
          case "PRESENT":
            statusColor = Colors.green;
            statusIcon = Icons.check_circle;
            break;
          case "WEEKLY OFF":
            statusColor = Colors.orange;
            statusIcon = Icons.beach_access;
            break;
          default:
            statusColor = Colors.red;
            statusIcon = Icons.cancel;
        }
        return GestureDetector(
          onLongPress: () {
            HapticFeedback.mediumImpact();
            onRecordLongPress(context, record);
          },
          child: Card(
            margin: const EdgeInsets.symmetric(vertical: 8),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              leading: Icon(statusIcon, color: statusColor, size: 30),
              title: Row(
                children: [
                  Text(DateFormat.yMMMMd().format(date), style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(width: 8),
                  Text(dayInitial, style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey[600])),
                ],
              ),
              subtitle: _buildSubtitle(context, checkIn, checkOut, status),
              trailing: (status == 'PRESENT' || status == 'ABSENT')
                  ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(status, style: TextStyle(color: status == 'PRESENT' ? Colors.green : Colors.red, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 2),
                  _buildStatusChip(record: record, isLate: isLate, isExpired: isExpired),
                ],
              )
                  : null,
            ),
          ),
        );
      },
    );
  }

  Widget _buildSubtitle(BuildContext context, String checkIn, String checkOut, String status) {
    TextStyle redStyle = const TextStyle(color: Colors.red, fontWeight: FontWeight.bold);
    TextStyle defaultStyle = TextStyle(color: Theme.of(context).textTheme.bodySmall?.color);

    if (status == 'PRESENT') {
      return RichText(
        text: TextSpan(
          style: defaultStyle,
          children: [
            const TextSpan(text: 'In: '),
            TextSpan(text: checkIn, style: checkIn == 'N/A' ? redStyle : null),
            const TextSpan(text: ' | Out: '),
            TextSpan(text: checkOut, style: checkOut == 'N/A' ? redStyle : null),
          ],
        ),
      );
    } else {
      return Text(status, style: TextStyle(color: Colors.grey[600]));
    }
  }

  // Updated status chip logic
  Widget _buildStatusChip({required Map<String, dynamic> record, required bool isLate, required bool isExpired}) {
    final approvalStatus = record['APPROVAL_STATUS']?.toString();
    final reason = record['REASON']?.toString();

    if (!isLate) {
      return const SizedBox.shrink(); // No chip if not late
    }

    String text;
    Color color;

    if (approvalStatus == '1') {
      text = 'Approved';
      color = Colors.green;
    } else if (approvalStatus == '0') {
      text = 'Not Approved';
      color = Colors.red;
    } else if (reason != null && reason.trim().isNotEmpty) {
      text = 'Pending';
      color = Colors.blue;
    } else if (isExpired) {
      text = 'Expired';
      color = Colors.grey;
    }
    else {
      return const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.warning_amber_rounded, color: Colors.amber, size: 14),
          SizedBox(width: 4),
          Text("LATE IN", style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold, fontSize: 10)),
        ],
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(4)),
      child: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 10)),
    );
  }
}
